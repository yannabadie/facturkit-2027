#!/usr/bin/env python3
"""
Suite de tests unitaires et d'intégration — Studio Factur-X Local 2027 (`facturx_cli.py`)
Exécution : python3 test_facturx.py
"""

from __future__ import annotations

import copy
import json
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import facturx_cli as fx  # noqa: E402


class TestFacturXEngine(unittest.TestCase):
    def setUp(self) -> None:
        self.samples = fx.get_sample_invoices()
        self.inv_franchise = copy.deepcopy(self.samples[0])
        self.inv_tva = copy.deepcopy(self.samples[1])

    def test_01_luhn_siren_and_siret_validation(self) -> None:
        # SIRENs réels / officiels valides Luhn
        self.assertTrue(fx.validate_siren("732829320"))
        self.assertTrue(fx.validate_siren("732 829 320"))
        self.assertTrue(fx.validate_siren("552100554"))
        self.assertTrue(fx.validate_siren("443061841"))

        # SIRENs invalides (fausse clé Luhn, longueur incorrecte, zéros)
        self.assertFalse(fx.validate_siren("732829321"))
        self.assertFalse(fx.validate_siren("123456789"))
        self.assertFalse(fx.validate_siren("000000000"))
        self.assertFalse(fx.validate_siren("73282932"))

        # SIRET valide (73282932000074 : 7+6+2+8+4+9+6+2+0+0+0+0+14(=5)+4 -> vérifions un SIRET Luhn exact)
        # Calcul d'un SIRET valide pour 732829320 + NIC 0007x :
        valid_sirets = [f"7328293200007{d}" for d in range(10) if fx.validate_siret(f"7328293200007{d}")]
        self.assertEqual(len(valid_sirets), 1)
        self.assertTrue(fx.validate_siret(valid_sirets[0]))
        self.assertFalse(fx.validate_siret("73282932100074"))  # SIREN de tête invalide

        # Exception officielle INSEE La Poste (SIREN 356000000, somme des 14 chiffres divisible par 5)
        # 3+5+6+0+0+0+0+0+0+0+0+0+1+0 = 15 (15 % 5 == 0)
        self.assertTrue(fx.validate_siret("35600000000010"))

    def test_02_french_vat_and_iban_modulo97(self) -> None:
        vat = fx.compute_french_vat("732829320")
        self.assertEqual(vat, "FR44732829320")
        # Construction dynamique d'un IBAN de test ISO 13616 valide pour tester Modulo-97 sans chaîne statique sensible
        bban = "30006000011234567890189"
        # Calcul clé IBAN FR : (98 - ((bban + '152700') % 97))
        chk = 98 - (int(bban + "152700") % 97)
        test_iban = f"FR{chk:02d}{bban}"
        self.assertTrue(fx.validate_iban(test_iban))
        self.assertFalse(fx.validate_iban(f"FR{(chk + 1) % 97:02d}{bban}"))

    def test_03_xml_generation_all_four_profiles(self) -> None:
        for prof_name, expected_urn in [
            ("MINIMUM", "urn:factur-x.eu:1p0:minimum"),
            ("BASIC_WL", "urn:factur-x.eu:1p0:basicwl"),
            ("BASIC", "urn:cen.eu:en16931:2017#compliant#urn:factur-x.eu:1p0:basic"),
            ("EN16931", "urn:cen.eu:en16931:2017"),
        ]:
            xml_bytes = fx.build_facturx_xml(self.inv_tva, profile=prof_name)
            xml_text = xml_bytes.decode("utf-8")
            self.assertIn("<rsm:CrossIndustryInvoice", xml_text)
            self.assertIn(expected_urn, xml_text)

            root = ET.fromstring(xml_bytes)
            self.assertTrue(root.tag.endswith("CrossIndustryInvoice"))

            audit = fx.inspect_facturx_bytes(xml_bytes, source_name=f"test_{prof_name}.xml")
            self.assertTrue(audit["valid"], msg=f"Échec profil {prof_name}: {audit['errors']}")
            self.assertEqual(audit["score"], 100)
            self.assertEqual(audit["summary"]["profile"], prof_name)
            self.assertEqual(audit["summary"]["tax_basis_ht"], "1080.00")
            self.assertEqual(audit["summary"]["tax_total"], "216.00")
            self.assertEqual(audit["summary"]["grand_total_ttc"], "1296.00")

    def test_04_franchise_293b_xml_mentions(self) -> None:
        xml_bytes = fx.build_facturx_xml(self.inv_franchise, profile="BASIC_WL")
        xml_text = xml_bytes.decode("utf-8")
        self.assertIn("VATEX-FR-FRANCHISE", xml_text)
        self.assertIn("293 B", xml_text)
        audit = fx.inspect_facturx_bytes(xml_bytes)
        self.assertTrue(audit["valid"])
        self.assertEqual(audit["summary"]["tax_basis_ht"], "1790.00")
        self.assertEqual(audit["summary"]["tax_total"], "0.00")
        self.assertEqual(audit["summary"]["grand_total_ttc"], "1790.00")

    def test_05_hybrid_pdf_generation_and_embedded_xml_roundtrip(self) -> None:
        xml_original = fx.build_facturx_xml(self.inv_tva, profile="EN16931")
        pdf_bytes = fx.build_facturx_pdf(self.inv_tva, xml_bytes=xml_original, profile="EN16931")

        self.assertTrue(pdf_bytes.startswith(b"%PDF-1.7"))
        self.assertIn(b"/EmbeddedFiles", pdf_bytes)
        self.assertIn(b"/AF", pdf_bytes)
        self.assertIn(b"factur-x.xml", pdf_bytes)

        extracted_xml, meta = fx.extract_facturx_xml_from_pdf(pdf_bytes)
        self.assertIsNotNone(extracted_xml)
        self.assertTrue(meta["has_embedded_files"])
        self.assertTrue(meta["has_af_tag"])
        self.assertTrue(meta["has_pdfa_xmp"])
        self.assertTrue(meta["has_facturx_xmp"])
        self.assertEqual(extracted_xml.strip(), xml_original.strip())

        audit = fx.inspect_facturx_bytes(pdf_bytes, source_name="FAC-2026-0105.pdf")
        self.assertTrue(audit["valid"], msg=f"Audit PDF échoué : {audit['errors']}")
        self.assertEqual(audit["score"], 100)

        # Cross-check indépendant avec pypdf si présent dans l'environnement Python
        try:
            import io
            from pypdf import PdfReader  # type: ignore

            reader = PdfReader(io.BytesIO(pdf_bytes))
            self.assertGreaterEqual(len(reader.pages), 1)
            self.assertIn("factur-x.xml", reader.attachments)
            attached_list = reader.attachments["factur-x.xml"]
            self.assertEqual(len(attached_list), 1)
            self.assertEqual(attached_list[0].strip(), xml_original.strip())
        except ImportError:
            pass

    def test_06_multi_page_invoice_pagination(self) -> None:
        big_inv = copy.deepcopy(self.inv_tva)
        big_inv["lines"] = [
            {
                "title": f"Lot de prestation technique n°{i} — Déploiement flux e-invoicing",
                "details": "Paramétrage connecteur et tests de conformité",
                "quantity": 1,
                "unit": "forfait",
                "unit_price_ht": "100.00",
                "vat_rate": "20.00",
            }
            for i in range(1, 25)
        ]
        pdf_bytes = fx.build_facturx_pdf(big_inv, profile="BASIC")
        self.assertIn(b"/Count 2", pdf_bytes)
        audit = fx.inspect_facturx_bytes(pdf_bytes)
        self.assertTrue(audit["valid"])
        self.assertEqual(audit["summary"]["grand_total_ttc"], "2880.00")

    def test_07_business_rules_reject_missing_or_invalid_b2b_siren(self) -> None:
        bad_inv = copy.deepcopy(self.inv_franchise)
        bad_inv["buyer"]["siren"] = ""
        with self.assertRaises(ValueError) as ctx:
            fx.build_facturx_xml(bad_inv)
        self.assertIn("SIREN du client professionnel", str(ctx.exception))

        bad_inv["buyer"]["siren"] = "732829329"  # Luhn invalide
        with self.assertRaises(ValueError) as ctx2:
            fx.build_facturx_xml(bad_inv)
        self.assertIn("Luhn", str(ctx2.exception))

    def test_08_inspector_detects_tampered_xml_totals_and_non_facturx_pdf(self) -> None:
        xml_bytes = fx.build_facturx_xml(self.inv_tva, profile="BASIC")
        tampered = xml_bytes.replace(b"<ram:GrandTotalAmount>1296.00</ram:GrandTotalAmount>", b"<ram:GrandTotalAmount>9999.00</ram:GrandTotalAmount>")
        audit = fx.inspect_facturx_bytes(tampered, source_name="tampered.xml")
        self.assertFalse(audit["valid"])
        self.assertTrue(any("Incohérence arithmétique" in e for e in audit["errors"]))

        plain_pdf = b"%PDF-1.4\n1 0 obj\n<< /Type /Catalog >>\nendobj\n%%EOF\n"
        audit_plain = fx.inspect_facturx_bytes(plain_pdf, source_name="plain.pdf")
        self.assertFalse(audit_plain["valid"])

    def test_09_cli_batch_demo_json_csv_and_verify(self) -> None:
        cli_path = Path(__file__).resolve().parent / "facturx_cli.py"
        with tempfile.TemporaryDirectory() as tmp:
            tmp_dir = Path(tmp)
            demo_dir = tmp_dir / "demo"
            out_json_dir = tmp_dir / "out_json"
            out_csv_dir = tmp_dir / "out_csv"

            r1 = subprocess.run([sys.executable, str(cli_path), "demo", "--outdir", str(demo_dir)], capture_output=True, text=True, check=False)
            self.assertEqual(r1.returncode, 0, msg=r1.stderr)
            self.assertTrue((demo_dir / "Facture_Exemple_FacturX_2027.pdf").exists())

            r2 = subprocess.run(
                [sys.executable, str(cli_path), "generate", "--input", str(demo_dir / "lot_factures_exemple.json"), "--outdir", str(out_json_dir)],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(r2.returncode, 0, msg=r2.stderr)

            r3 = subprocess.run(
                [sys.executable, str(cli_path), "generate", "--input", str(demo_dir / "lot_factures_exemple.csv"), "--outdir", str(out_csv_dir)],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(r3.returncode, 0, msg=r3.stderr)

            r4 = subprocess.run(
                [sys.executable, str(cli_path), "verify", str(out_csv_dir), "--json"],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(r4.returncode, 0, msg=r4.stderr)
            parsed = json.loads(r4.stdout)
            self.assertEqual(len(parsed), 4)  # 2 PDF + 2 XML
            self.assertTrue(all(item["valid"] for item in parsed))


if __name__ == "__main__":
    unittest.main(verbosity=2)
