#!/usr/bin/env python3
"""
Studio Factur-X Local 2027 — Utilitaire CLI & Moteur Factur-X (EN 16931 CII / PDF-A3)
=====================================================================================
100% autonome (bibliothèque standard Python 3 uniquement, zéro dépendance externe).

Fonctionnalités :
  - Validation algorithmique réelle Luhn (SIREN 9 chiffres / SIRET 14 chiffres + règle La Poste),
    calcul de clé TVA intracommunautaire française et validation Modulo-97 IBAN.
  - Génération exacte du fichier XML Factur-X 1.0.07 (UN/CEFACT CrossIndustryInvoice CII)
    selon les profils officiels : MINIMUM, BASIC WL, BASIC, EN 16931 (COMFORT).
  - Génération de vraies factures PDF/A-3 hybrides embarquant `factur-x.xml` dans
    `/EmbeddedFiles` + `/AF` + métadonnées XMP PDF/A-3B & Factur-X, avec rendu visuel B2B soigné.
  - Extraction et audit structurel/réglementaire (réforme sept. 2026 / sept. 2027) de factures
    fournisseurs reçues au format PDF Factur-X ou XML CII, à l'unité ou en lot.
  - Génération en lot depuis un fichier JSON ou CSV.

Exemples d'utilisation :
  python3 facturx_cli.py demo --outdir ./exemples
  python3 facturx_cli.py generate --input ./exemples/lot_factures_exemple.json --outdir ./sortie
  python3 facturx_cli.py generate --input ./exemples/lot_factures_exemple.csv --outdir ./sortie
  python3 facturx_cli.py verify ./exemples/Facture_Exemple_FacturX_2027.pdf
  python3 facturx_cli.py check-siren 732829320
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
import zlib
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Constantes Factur-X 1.0.07 / UN-CEFACT CII / EN 16931
# ---------------------------------------------------------------------------

NS_RSM = "urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100"
NS_QDT = "urn:un:unece:uncefact:data:standard:QualifiedDataType:100"
NS_RAM = "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100"
NS_UDT = "urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100"
NS_XS = "http://www.w3.org/2001/XMLSchema"

PROFILES: Dict[str, Dict[str, Any]] = {
    "MINIMUM": {
        "urn": "urn:factur-x.eu:1p0:minimum",
        "xmp_level": "MINIMUM",
        "has_lines": False,
        "has_tax_breakdown": False,
        "has_notes": False,
    },
    "BASIC_WL": {
        "urn": "urn:factur-x.eu:1p0:basicwl",
        "xmp_level": "BASIC WL",
        "has_lines": False,
        "has_tax_breakdown": True,
        "has_notes": True,
    },
    "BASIC": {
        "urn": "urn:cen.eu:en16931:2017#compliant#urn:factur-x.eu:1p0:basic",
        "xmp_level": "BASIC",
        "has_lines": True,
        "has_tax_breakdown": True,
        "has_notes": True,
    },
    "EN16931": {
        "urn": "urn:cen.eu:en16931:2017",
        "xmp_level": "EN 16931",
        "has_lines": True,
        "has_tax_breakdown": True,
        "has_notes": True,
    },
}

PROFILE_ALIASES = {
    "MINIMUM": "MINIMUM",
    "BASIC WL": "BASIC_WL",
    "BASIC_WL": "BASIC_WL",
    "BASICWL": "BASIC_WL",
    "BASIC": "BASIC",
    "EN16931": "EN16931",
    "EN 16931": "EN16931",
    "COMFORT": "EN16931",
}

OPERATION_NATURES = {
    "SERVICES": "Prestation de services",
    "BIENS": "Livraison de biens",
    "MIXTE": "Opération mixte (livraison de biens et prestation de services)",
    "Prestation de services": "Prestation de services",
    "Livraison de biens": "Livraison de biens",
    "Mixte": "Opération mixte (livraison de biens et prestation de services)",
    "Opération mixte (livraison de biens et prestation de services)": "Opération mixte (livraison de biens et prestation de services)",
}

UNIT_CODE_MAP = {
    "unité": "C62",
    "unite": "C62",
    "u": "C62",
    "c62": "C62",
    "forfait": "C62",
    "lot": "C62",
    "heure": "HUR",
    "heures": "HUR",
    "h": "HUR",
    "hur": "HUR",
    "jour": "DAY",
    "jours": "DAY",
    "j": "DAY",
    "day": "DAY",
    "mois": "MON",
    "mon": "MON",
}

# Mapping Unicode -> Windows-1252 (WinAnsiEncoding) pour les caractères hors Latin-1 (0x80..0x9F)
CP1252_EXTRA_MAP: Dict[int, int] = {
    0x20AC: 0x80,  # €
    0x201A: 0x82,  # ‚
    0x0192: 0x83,  # ƒ
    0x201E: 0x84,  # „
    0x2026: 0x85,  # …
    0x2020: 0x86,  # †
    0x2021: 0x87,  # ‡
    0x02C6: 0x88,  # ˆ
    0x2030: 0x89,  # ‰
    0x0160: 0x8A,  # Š
    0x2039: 0x8B,  # ‹
    0x0152: 0x8C,  # Œ
    0x017D: 0x8E,  # Ž
    0x2018: 0x91,  # ‘
    0x2019: 0x92,  # ’
    0x201C: 0x93,  # “
    0x201D: 0x94,  # ”
    0x2022: 0x95,  # •
    0x2013: 0x96,  # –
    0x2014: 0x97,  # —
    0x02DC: 0x98,  # ˜
    0x2122: 0x99,  # ™
    0x0161: 0x9A,  # š
    0x203A: 0x9B,  # ›
    0x0153: 0x9C,  # œ
    0x017E: 0x9E,  # ž
    0x0178: 0x9F,  # Ÿ
}


# ---------------------------------------------------------------------------
# Utilitaires financiers & validations réglementaires (Luhn, TVA, IBAN)
# ---------------------------------------------------------------------------

def dec2(val: Any) -> Decimal:
    """Arrondi monétaire comptable à 2 décimales (ROUND_HALF_UP)."""
    if isinstance(val, Decimal):
        d = val
    else:
        s = str(val).strip().replace(",", ".").replace(" ", "").replace("\u00a0", "")
        d = Decimal(s or "0")
    return d.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def fmt_amount(val: Any) -> str:
    return f"{dec2(val):.2f}"


def fmt_fr_currency(val: Any, currency: str = "EUR") -> str:
    d = dec2(val)
    sign = "-" if d < 0 else ""
    abs_d = abs(d)
    int_part = int(abs_d)
    frac_part = int((abs_d - int_part) * 100)
    int_str = f"{int_part:,}".replace(",", " ")
    sym = "€" if currency.upper() == "EUR" else currency.upper()
    return f"{sign}{int_str},{frac_part:02d} {sym}"


def clean_digits(value: str) -> str:
    return re.sub(r"\s+|[-.]", "", str(value or ""))


def validate_luhn(digits: str) -> bool:
    """Algorithme de Luhn standard sur une chaîne numérique."""
    if not digits or not digits.isdigit():
        return False
    total = 0
    reverse_digits = digits[::-1]
    for idx, ch in enumerate(reverse_digits):
        n = ord(ch) - 48
        if idx % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return (total % 10) == 0


def validate_siren(siren: str) -> bool:
    """Valide un numéro SIREN français (9 chiffres + clé de Luhn, non nul)."""
    cleaned = clean_digits(siren)
    if len(cleaned) != 9 or not cleaned.isdigit() or cleaned == "000000000":
        return False
    return validate_luhn(cleaned)


def validate_siret(siret: str) -> bool:
    """Valide un numéro SIRET français (14 chiffres + Luhn + exception INSEE La Poste)."""
    cleaned = clean_digits(siret)
    if len(cleaned) != 14 or not cleaned.isdigit() or cleaned == "00000000000000":
        return False
    siren_part = cleaned[:9]
    if not validate_siren(siren_part):
        return False
    if validate_luhn(cleaned):
        return True
    # Exception officielle INSEE pour les établissements de La Poste (SIREN 356000000)
    if siren_part == "356000000":
        digit_sum = sum(ord(c) - 48 for c in cleaned)
        return (digit_sum % 5) == 0
    return False


def extract_siren(siren_or_siret: str) -> str:
    cleaned = clean_digits(siren_or_siret)
    if len(cleaned) == 14 and validate_siret(cleaned):
        return cleaned[:9]
    if len(cleaned) == 9 and validate_siren(cleaned):
        return cleaned
    return cleaned[:9]


def compute_french_vat(siren: str) -> str:
    """Calcule le numéro de TVA intracommunautaire français à partir d'un SIREN valide."""
    cleaned = extract_siren(siren)
    if not validate_siren(cleaned):
        raise ValueError(f"SIREN invalide (échec Luhn) : {siren!r}")
    key = (12 + 3 * (int(cleaned) % 97)) % 97
    return f"FR{key:02d}{cleaned}"


def validate_iban(iban: str) -> bool:
    """Validation internationale ISO 13616 Modulo-97 d'un IBAN."""
    cleaned = re.sub(r"\s+", "", str(iban or "")).upper()
    if len(cleaned) < 15 or len(cleaned) > 34:
        return False
    if not re.match(r"^[A-Z]{2}[0-9]{2}[A-Z0-9]+$", cleaned):
        return False
    if cleaned.startswith("FR") and len(cleaned) != 27:
        return False
    rearranged = cleaned[4:] + cleaned[:4]
    numeric_chars: List[str] = []
    for ch in rearranged:
        if ch.isdigit():
            numeric_chars.append(ch)
        else:
            numeric_chars.append(str(ord(ch) - 55))
    return (int("".join(numeric_chars)) % 97) == 1


def normalize_date_102(date_str: str) -> str:
    """Convertit YYYY-MM-DD, DD/MM/YYYY ou YYYYMMDD au format CII 102 (YYYYMMDD)."""
    s = str(date_str or "").strip()
    if not s:
        return dt.date.today().strftime("%Y%m%d")
    if re.match(r"^\d{8}$", s):
        dt.datetime.strptime(s, "%Y%m%d")
        return s
    if re.match(r"^\d{4}-\d{2}-\d{2}$", s):
        return dt.datetime.strptime(s, "%Y-%m-%d").strftime("%Y%m%d")
    if re.match(r"^\d{2}/\d{2}/\d{4}$", s):
        return dt.datetime.strptime(s, "%d/%m/%Y").strftime("%Y%m%d")
    raise ValueError(f"Format de date non reconnu : {date_str!r} (attendu YYYY-MM-DD ou DD/MM/YYYY)")


def format_date_fr(date_str: str) -> str:
    d102 = normalize_date_102(date_str)
    return f"{d102[6:8]}/{d102[4:6]}/{d102[0:4]}"


def normalize_profile(profile: str) -> str:
    key = str(profile or "BASIC").strip().upper()
    if key not in PROFILE_ALIASES:
        raise ValueError(f"Profil Factur-X inconnu : {profile!r}. Profils supportés : {list(PROFILES.keys())}")
    return PROFILE_ALIASES[key]


# ---------------------------------------------------------------------------
# Calculs de facture & Validation Métier 2026-2027
# ---------------------------------------------------------------------------

def compute_invoice_totals(invoice: Dict[str, Any]) -> Dict[str, Any]:
    """Calcule les sous-totaux par ligne, la ventilation TVA et les totaux HT / TVA / TTC."""
    seller = invoice.get("seller", {})
    vat_regime = str(seller.get("vat_regime") or invoice.get("vat_regime") or "FRANCHISE_293B").upper()
    is_franchise = vat_regime in ("FRANCHISE_293B", "FRANCHISE", "MICRO_293B", "EXEMPT_293B")

    raw_lines = invoice.get("lines") or []
    if not raw_lines:
        raise ValueError("La facture doit contenir au moins une ligne de prestation ou de bien.")

    computed_lines: List[Dict[str, Any]] = []
    tax_buckets: Dict[Tuple[str, Decimal], Decimal] = {}
    line_total_ht = Decimal("0.00")

    for idx, line in enumerate(raw_lines, start=1):
        qty = Decimal(str(line.get("quantity", 1)).replace(",", "."))
        unit_price = Decimal(str(line.get("unit_price_ht", line.get("unit_price", 0))).replace(",", "."))
        discount_pct = Decimal(str(line.get("discount_percent", 0)).replace(",", "."))
        effective_unit = unit_price * (Decimal("1") - (discount_pct / Decimal("100")))
        net_unit = dec2(effective_unit)
        line_ht = dec2(qty * net_unit)

        if is_franchise:
            vat_rate = Decimal("0.00")
            cat_code = "E"
        else:
            vat_rate = dec2(line.get("vat_rate", 20))
            cat_code = str(line.get("vat_category") or ("S" if vat_rate > 0 else "Z")).upper()

        line_total_ht += line_ht
        bucket_key = (cat_code, vat_rate)
        tax_buckets[bucket_key] = tax_buckets.get(bucket_key, Decimal("0.00")) + line_ht

        unit_label = str(line.get("unit", "unité"))
        unit_code = UNIT_CODE_MAP.get(unit_label.lower(), str(line.get("unit_code", "C62")).upper())

        computed_lines.append({
            "line_id": str(line.get("line_id", idx)),
            "title": str(line.get("title") or line.get("description") or f"Prestation #{idx}").strip(),
            "description": str(line.get("details") or "").strip(),
            "quantity": qty,
            "unit": unit_label,
            "unit_code": unit_code,
            "unit_price_ht": dec2(unit_price),
            "discount_percent": dec2(discount_pct),
            "net_unit_price_ht": net_unit,
            "vat_rate": vat_rate,
            "vat_category": cat_code,
            "line_total_ht": line_ht,
        })

    # DueDateTypeCode EN 16931 BT-8 : 5 = TVA sur les débits (date facture), 72 = TVA sur les encaissements
    due_date_type = "5" if vat_regime == "TVA_DEBITS" else ("72" if vat_regime == "TVA_ENCAISSEMENTS" else "")

    tax_breakdown: List[Dict[str, Any]] = []
    total_vat = Decimal("0.00")
    for (cat_code, rate), basis in sorted(tax_buckets.items(), key=lambda x: x[0][1], reverse=True):
        tax_amt = dec2(basis * rate / Decimal("100"))
        total_vat += tax_amt
        entry: Dict[str, Any] = {
            "category_code": cat_code,
            "rate": rate,
            "basis_amount": dec2(basis),
            "tax_amount": tax_amt,
            "due_date_type_code": due_date_type if cat_code == "S" else "",
        }
        if is_franchise or cat_code == "E":
            entry["exemption_reason"] = "TVA non applicable, art. 293 B du CGI"
            entry["exemption_reason_code"] = "VATEX-FR-FRANCHISE"
        tax_breakdown.append(entry)

    grand_total_ttc = dec2(line_total_ht + total_vat)
    prepaid = dec2(invoice.get("prepaid_amount", "0.00"))
    due_payable = dec2(grand_total_ttc - prepaid)

    return {
        "is_franchise": is_franchise,
        "vat_regime": vat_regime,
        "lines": computed_lines,
        "tax_breakdown": tax_breakdown,
        "line_total_ht": dec2(line_total_ht),
        "tax_basis_total_ht": dec2(line_total_ht),
        "tax_total_amount": dec2(total_vat),
        "grand_total_ttc": grand_total_ttc,
        "prepaid_amount": prepaid,
        "due_payable_amount": due_payable,
    }


def validate_invoice_business_rules(invoice: Dict[str, Any]) -> Tuple[List[str], List[str]]:
    """Vérifie la conformité réglementaire française 2026-2027 avant émission."""
    errors: List[str] = []
    warnings: List[str] = []

    inv_num = str(invoice.get("number", "")).strip()
    if not inv_num:
        errors.append("Numéro de document séquentiel manquant.")

    seller = invoice.get("seller") or {}
    buyer = invoice.get("buyer") or {}

    if not str(seller.get("name", "")).strip():
        errors.append("Raison sociale / Nom de l'émetteur manquant.")

    seller_siren_raw = clean_digits(seller.get("siret") or seller.get("siren") or "")
    if len(seller_siren_raw) == 14:
        if not validate_siret(seller_siren_raw):
            errors.append(f"SIRET émetteur invalide (échec contrôle Luhn) : {seller_siren_raw}")
    elif len(seller_siren_raw) == 9:
        if not validate_siren(seller_siren_raw):
            errors.append(f"SIREN émetteur invalide (échec contrôle Luhn) : {seller_siren_raw}")
    else:
        errors.append("SIREN (9 chiffres) ou SIRET (14 chiffres) émetteur obligatoire.")

    is_b2b = bool(buyer.get("is_b2b", True))
    if not str(buyer.get("name", "")).strip():
        errors.append("Nom / Raison sociale du client manquant.")

    buyer_siren_raw = clean_digits(buyer.get("siret") or buyer.get("siren") or "")
    doc_type = str(invoice.get("doc_type", "380")).strip()
    if is_b2b and doc_type in ("380", "381"):
        if not buyer_siren_raw:
            errors.append("Mention obligatoire 2026-2027 manquante : SIREN du client professionnel (B2B).")
        elif len(buyer_siren_raw) == 14 and not validate_siret(buyer_siren_raw):
            errors.append(f"SIRET client B2B invalide (échec Luhn) : {buyer_siren_raw}")
        elif len(buyer_siren_raw) == 9 and not validate_siren(buyer_siren_raw):
            errors.append(f"SIREN client B2B invalide (échec Luhn) : {buyer_siren_raw}")
        elif len(buyer_siren_raw) not in (9, 14):
            errors.append(f"Format SIREN/SIRET client B2B incorrect ({buyer_siren_raw}).")

    op_nature = str(invoice.get("operation_nature", "")).strip()
    if not op_nature:
        errors.append("Mention obligatoire 2026-2027 manquante : Nature de l'opération (Prestation de services / Livraison de biens / Mixte).")

    iban = str(seller.get("iban", "")).strip()
    if iban and not validate_iban(iban):
        errors.append(f"IBAN émetteur invalide (échec clé Modulo-97) : {iban}")

    if seller.get("is_ei") and "ei" not in str(seller.get("name", "")).lower() and "entrepreneur individuel" not in str(seller.get("legal_form", "")).lower():
        warnings.append("Pensez à faire figurer la mention « EI » ou « Entrepreneur Individuel » accolée à votre nom (obligation depuis mai 2022).")

    return errors, warnings


# ---------------------------------------------------------------------------
# Générateur XML Factur-X 1.0.07 (UN/CEFACT CrossIndustryInvoice CII)
# ---------------------------------------------------------------------------

def _xml_escape(text: Any) -> str:
    s = str(text if text is not None else "")
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def build_facturx_xml(invoice: Dict[str, Any], profile: str = "BASIC") -> bytes:
    """
    Construit le fichier XML Factur-X 1.0.07 (UN/CEFACT CrossIndustryInvoice CII)
    strictement conforme au profil demandé (MINIMUM, BASIC_WL, BASIC, EN16931).
    """
    prof_key = normalize_profile(profile or invoice.get("profile", "BASIC"))
    prof = PROFILES[prof_key]

    errors, _ = validate_invoice_business_rules(invoice)
    if errors:
        raise ValueError("Facture non conforme : " + " | ".join(errors))

    totals = compute_invoice_totals(invoice)
    seller = invoice["seller"]
    buyer = invoice["buyer"]
    currency = str(invoice.get("currency", "EUR")).upper()

    inv_number = str(invoice["number"]).strip()
    type_code = str(invoice.get("doc_type", "380")).strip()
    if type_code == "DEVIS":
        type_code = "325"  # Proforma / Devis

    issue_date = normalize_date_102(invoice.get("issue_date", ""))
    delivery_date = normalize_date_102(invoice.get("delivery_date") or invoice.get("issue_date") or "")
    due_date = normalize_date_102(invoice.get("due_date") or invoice.get("issue_date") or "")

    seller_siren = extract_siren(seller.get("siret") or seller.get("siren") or "")
    buyer_siren = extract_siren(buyer.get("siret") or buyer.get("siren") or "") if (buyer.get("siret") or buyer.get("siren")) else ""

    seller_vat = str(seller.get("vat_number") or "").strip()
    if not totals["is_franchise"] and not seller_vat and validate_siren(seller_siren):
        seller_vat = compute_french_vat(seller_siren)

    op_label = OPERATION_NATURES.get(
        str(invoice.get("operation_nature", "Prestation de services")).strip(),
        str(invoice.get("operation_nature", "Prestation de services")).strip(),
    )
    late_penalty = str(
        invoice.get("late_penalty_text")
        or "Pénalités de retard exigibles sans rappel dès le lendemain de l'échéance : 3 fois le taux d'intérêt légal en vigueur (art. L441-10 du Code de commerce)."
    )
    recovery_fee = str(
        invoice.get("recovery_indemnity_text")
        or "Indemnité forfaitaire pour frais de recouvrement en cas de retard de paiement : 40,00 EUR (art. L441-10 et D441-5 du Code de commerce)."
    )
    discount_terms = str(
        invoice.get("early_discount_text")
        or "Pas d'escompte accordé pour paiement anticipé."
    )

    vat_regime_note = (
        "TVA non applicable, art. 293 B du CGI (Franchise en base de TVA)."
        if totals["is_franchise"]
        else (
            "Option pour le paiement de la taxe d'après les débits."
            if totals["vat_regime"] == "TVA_DEBITS"
            else "TVA acquittée sur les encaissements."
        )
    )

    xml_lines: List[str] = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<rsm:CrossIndustryInvoice',
        f'  xmlns:rsm="{NS_RSM}"',
        f'  xmlns:qdt="{NS_QDT}"',
        f'  xmlns:ram="{NS_RAM}"',
        f'  xmlns:xs="{NS_XS}"',
        f'  xmlns:udt="{NS_UDT}">',
        '  <rsm:ExchangedDocumentContext>',
        '    <ram:GuidelineSpecifiedDocumentContextParameter>',
        f'      <ram:ID>{_xml_escape(prof["urn"])}</ram:ID>',
        '    </ram:GuidelineSpecifiedDocumentContextParameter>',
        '  </rsm:ExchangedDocumentContext>',
        '  <rsm:ExchangedDocument>',
        f'    <ram:ID>{_xml_escape(inv_number)}</ram:ID>',
        f'    <ram:TypeCode>{_xml_escape(type_code)}</ram:TypeCode>',
        '    <ram:IssueDateTime>',
        f'      <udt:DateTimeString format="102">{issue_date}</udt:DateTimeString>',
        '    </ram:IssueDateTime>',
    ]

    if prof["has_notes"]:
        notes = [
            (f"Nature de l'opération : {op_label} — {vat_regime_note}", "REG"),
        ]
        if buyer.get("is_b2b", True):
            notes.extend([
                (late_penalty, "PMD"),
                (recovery_fee, "PMT"),
                (discount_terms, "AAB"),
            ])
        if invoice.get("notes"):
            notes.append((str(invoice["notes"]).strip(), "AAI"))

        for content, subj in notes:
            xml_lines.extend([
                '    <ram:IncludedNote>',
                f'      <ram:Content>{_xml_escape(content)}</ram:Content>',
                f'      <ram:SubjectCode>{_xml_escape(subj)}</ram:SubjectCode>',
                '    </ram:IncludedNote>',
            ])

    xml_lines.extend([
        '  </rsm:ExchangedDocument>',
        '  <rsm:SupplyChainTradeTransaction>',
    ])

    # 1. Lignes de détail (BASIC & EN 16931)
    if prof["has_lines"]:
        for item in totals["lines"]:
            xml_lines.extend([
                '    <ram:IncludedSupplyChainTradeLineItem>',
                '      <ram:AssociatedDocumentLineDocument>',
                f'        <ram:LineID>{_xml_escape(item["line_id"])}</ram:LineID>',
                '      </ram:AssociatedDocumentLineDocument>',
                '      <ram:SpecifiedTradeProduct>',
                f'        <ram:Name>{_xml_escape(item["title"])}</ram:Name>',
            ])
            if item["description"] and prof_key == "EN16931":
                xml_lines.append(f'        <ram:Description>{_xml_escape(item["description"])}</ram:Description>')
            xml_lines.extend([
                '      </ram:SpecifiedTradeProduct>',
                '      <ram:SpecifiedLineTradeAgreement>',
                '        <ram:NetPriceProductTradePrice>',
                f'          <ram:ChargeAmount>{fmt_amount(item["net_unit_price_ht"])}</ram:ChargeAmount>',
                '        </ram:NetPriceProductTradePrice>',
                '      </ram:SpecifiedLineTradeAgreement>',
                '      <ram:SpecifiedLineTradeDelivery>',
                f'        <ram:BilledQuantity unitCode="{_xml_escape(item["unit_code"])}">{item["quantity"]:.2f}</ram:BilledQuantity>',
                '      </ram:SpecifiedLineTradeDelivery>',
                '      <ram:SpecifiedLineTradeSettlement>',
                '        <ram:ApplicableTradeTax>',
                '          <ram:TypeCode>VAT</ram:TypeCode>',
                f'          <ram:CategoryCode>{_xml_escape(item["vat_category"])}</ram:CategoryCode>',
                f'          <ram:RateApplicablePercent>{fmt_amount(item["vat_rate"])}</ram:RateApplicablePercent>',
                '        </ram:ApplicableTradeTax>',
                '        <ram:SpecifiedTradeSettlementLineMonetarySummation>',
                f'          <ram:LineTotalAmount>{fmt_amount(item["line_total_ht"])}</ram:LineTotalAmount>',
                '        </ram:SpecifiedTradeSettlementLineMonetarySummation>',
                '      </ram:SpecifiedLineTradeSettlement>',
                '    </ram:IncludedSupplyChainTradeLineItem>',
            ])

    # 2. ApplicableHeaderTradeAgreement (Vendeur, Acheteur, Références)
    xml_lines.append('    <ram:ApplicableHeaderTradeAgreement>')
    if invoice.get("buyer_reference"):
        xml_lines.append(f'      <ram:BuyerReference>{_xml_escape(invoice["buyer_reference"])}</ram:BuyerReference>')

    # Vendeur
    seller_display_name = str(seller["name"]).strip()
    if seller.get("is_ei") and "ei" not in seller_display_name.lower():
        seller_display_name = f"{seller_display_name} (EI)"

    xml_lines.extend([
        '      <ram:SellerTradeParty>',
        f'        <ram:Name>{_xml_escape(seller_display_name)}</ram:Name>',
        '        <ram:SpecifiedLegalOrganization>',
        f'          <ram:ID schemeID="0002">{_xml_escape(seller_siren)}</ram:ID>',
        '        </ram:SpecifiedLegalOrganization>',
        '        <ram:PostalTradeAddress>',
    ])
    if prof_key != "MINIMUM":
        if seller.get("postal_code"):
            xml_lines.append(f'          <ram:PostcodeCode>{_xml_escape(seller["postal_code"])}</ram:PostcodeCode>')
        if seller.get("address"):
            xml_lines.append(f'          <ram:LineOne>{_xml_escape(seller["address"])}</ram:LineOne>')
        if seller.get("city"):
            xml_lines.append(f'          <ram:CityName>{_xml_escape(seller["city"])}</ram:CityName>')
    xml_lines.extend([
        f'          <ram:CountryID>{_xml_escape(seller.get("country", "FR"))}</ram:CountryID>',
        '        </ram:PostalTradeAddress>',
    ])
    if seller.get("email") and prof_key in ("BASIC", "EN16931"):
        xml_lines.extend([
            '        <ram:URIUniversalCommunication>',
            f'          <ram:URIID schemeID="EM">{_xml_escape(seller["email"])}</ram:URIID>',
            '        </ram:URIUniversalCommunication>',
        ])
    if seller_vat:
        xml_lines.extend([
            '        <ram:SpecifiedTaxRegistration>',
            f'          <ram:ID schemeID="VA">{_xml_escape(seller_vat)}</ram:ID>',
            '        </ram:SpecifiedTaxRegistration>',
        ])
    xml_lines.append('      </ram:SellerTradeParty>')

    # Acheteur
    xml_lines.extend([
        '      <ram:BuyerTradeParty>',
        f'        <ram:Name>{_xml_escape(buyer["name"])}</ram:Name>',
    ])
    if buyer_siren:
        xml_lines.extend([
            '        <ram:SpecifiedLegalOrganization>',
            f'          <ram:ID schemeID="0002">{_xml_escape(buyer_siren)}</ram:ID>',
            '        </ram:SpecifiedLegalOrganization>',
        ])
    if prof_key != "MINIMUM":
        xml_lines.append('        <ram:PostalTradeAddress>')
        if buyer.get("postal_code"):
            xml_lines.append(f'          <ram:PostcodeCode>{_xml_escape(buyer["postal_code"])}</ram:PostcodeCode>')
        if buyer.get("address"):
            xml_lines.append(f'          <ram:LineOne>{_xml_escape(buyer["address"])}</ram:LineOne>')
        if buyer.get("city"):
            xml_lines.append(f'          <ram:CityName>{_xml_escape(buyer["city"])}</ram:CityName>')
        xml_lines.extend([
            f'          <ram:CountryID>{_xml_escape(buyer.get("country", "FR"))}</ram:CountryID>',
            '        </ram:PostalTradeAddress>',
        ])
    if buyer.get("email") and prof_key in ("BASIC", "EN16931"):
        xml_lines.extend([
            '        <ram:URIUniversalCommunication>',
            f'          <ram:URIID schemeID="EM">{_xml_escape(buyer["email"])}</ram:URIID>',
            '        </ram:URIUniversalCommunication>',
        ])
    if buyer.get("vat_number") and prof_key != "MINIMUM":
        xml_lines.extend([
            '        <ram:SpecifiedTaxRegistration>',
            f'          <ram:ID schemeID="VA">{_xml_escape(buyer["vat_number"])}</ram:ID>',
            '        </ram:SpecifiedTaxRegistration>',
        ])
    xml_lines.append('      </ram:BuyerTradeParty>')

    if invoice.get("order_reference"):
        xml_lines.extend([
            '      <ram:BuyerOrderReferencedDocument>',
            f'        <ram:IssuerAssignedID>{_xml_escape(invoice["order_reference"])}</ram:IssuerAssignedID>',
            '      </ram:BuyerOrderReferencedDocument>',
        ])

    xml_lines.append('    </ram:ApplicableHeaderTradeAgreement>')

    # 3. ApplicableHeaderTradeDelivery (Adresse de livraison distincte & date d'opération)
    if prof_key == "MINIMUM":
        xml_lines.append('    <ram:ApplicableHeaderTradeDelivery/>')
    else:
        xml_lines.append('    <ram:ApplicableHeaderTradeDelivery>')
        delivery_addr = invoice.get("delivery_address") or {}
        if delivery_addr and (delivery_addr.get("address") or delivery_addr.get("city")):
            xml_lines.extend([
                '      <ram:ShipToTradeParty>',
                f'        <ram:Name>{_xml_escape(delivery_addr.get("name") or buyer["name"])}</ram:Name>',
                '        <ram:PostalTradeAddress>',
            ])
            if delivery_addr.get("postal_code"):
                xml_lines.append(f'          <ram:PostcodeCode>{_xml_escape(delivery_addr["postal_code"])}</ram:PostcodeCode>')
            if delivery_addr.get("address"):
                xml_lines.append(f'          <ram:LineOne>{_xml_escape(delivery_addr["address"])}</ram:LineOne>')
            if delivery_addr.get("city"):
                xml_lines.append(f'          <ram:CityName>{_xml_escape(delivery_addr["city"])}</ram:CityName>')
            xml_lines.extend([
                f'          <ram:CountryID>{_xml_escape(delivery_addr.get("country", "FR"))}</ram:CountryID>',
                '        </ram:PostalTradeAddress>',
                '      </ram:ShipToTradeParty>',
            ])
        xml_lines.extend([
            '      <ram:ActualDeliverySupplyChainEvent>',
            '        <ram:OccurrenceDateTime>',
            f'          <udt:DateTimeString format="102">{delivery_date}</udt:DateTimeString>',
            '        </ram:OccurrenceDateTime>',
            '      </ram:ActualDeliverySupplyChainEvent>',
            '    </ram:ApplicableHeaderTradeDelivery>',
        ])

    # 4. ApplicableHeaderTradeSettlement (Devise, Paiement, Ventilation TVA, Totaux)
    xml_lines.extend([
        '    <ram:ApplicableHeaderTradeSettlement>',
        f'      <ram:InvoiceCurrencyCode>{_xml_escape(currency)}</ram:InvoiceCurrencyCode>',
    ])

    if prof_key != "MINIMUM":
        payment_code = str(invoice.get("payment_means_code", "30")).strip()
        xml_lines.extend([
            '      <ram:SpecifiedTradeSettlementPaymentMeans>',
            f'        <ram:TypeCode>{_xml_escape(payment_code)}</ram:TypeCode>',
        ])
        iban_clean = re.sub(r"\s+", "", str(seller.get("iban") or "")).upper()
        if iban_clean:
            xml_lines.extend([
                '        <ram:PayeePartyCreditorFinancialAccount>',
                f'          <ram:IBANID>{_xml_escape(iban_clean)}</ram:IBANID>',
                '        </ram:PayeePartyCreditorFinancialAccount>',
            ])
            if seller.get("bic") and prof_key == "EN16931":
                xml_lines.extend([
                    '        <ram:PayeeSpecifiedCreditorFinancialInstitution>',
                    f'          <ram:BICID>{_xml_escape(seller["bic"])}</ram:BICID>',
                    '        </ram:PayeeSpecifiedCreditorFinancialInstitution>',
                ])
        xml_lines.append('      </ram:SpecifiedTradeSettlementPaymentMeans>')

    if prof["has_tax_breakdown"]:
        for tb in totals["tax_breakdown"]:
            xml_lines.extend([
                '      <ram:ApplicableTradeTax>',
                f'        <ram:CalculatedAmount>{fmt_amount(tb["tax_amount"])}</ram:CalculatedAmount>',
                '        <ram:TypeCode>VAT</ram:TypeCode>',
            ])
            if tb.get("exemption_reason"):
                xml_lines.append(f'        <ram:ExemptionReason>{_xml_escape(tb["exemption_reason"])}</ram:ExemptionReason>')
            xml_lines.extend([
                f'        <ram:BasisAmount>{fmt_amount(tb["basis_amount"])}</ram:BasisAmount>',
                f'        <ram:CategoryCode>{_xml_escape(tb["category_code"])}</ram:CategoryCode>',
            ])
            if tb.get("exemption_reason_code"):
                xml_lines.append(f'        <ram:ExemptionReasonCode>{_xml_escape(tb["exemption_reason_code"])}</ram:ExemptionReasonCode>')
            if tb.get("due_date_type_code"):
                xml_lines.append(f'        <ram:DueDateTypeCode>{_xml_escape(tb["due_date_type_code"])}</ram:DueDateTypeCode>')
            xml_lines.extend([
                f'        <ram:RateApplicablePercent>{fmt_amount(tb["rate"])}</ram:RateApplicablePercent>',
                '      </ram:ApplicableTradeTax>',
            ])

    if prof_key != "MINIMUM":
        payment_terms_desc = str(invoice.get("payment_terms") or f"Règlement à échéance le {format_date_fr(due_date)}.")
        xml_lines.extend([
            '      <ram:SpecifiedTradePaymentTerms>',
            f'        <ram:Description>{_xml_escape(payment_terms_desc)}</ram:Description>',
            '        <ram:DueDateDateTime>',
            f'          <udt:DateTimeString format="102">{due_date}</udt:DateTimeString>',
            '        </ram:DueDateDateTime>',
            '      </ram:SpecifiedTradePaymentTerms>',
        ])

    xml_lines.append('      <ram:SpecifiedTradeSettlementHeaderMonetarySummation>')
    if prof_key != "MINIMUM":
        xml_lines.append(f'        <ram:LineTotalAmount>{fmt_amount(totals["line_total_ht"])}</ram:LineTotalAmount>')
    xml_lines.extend([
        f'        <ram:TaxBasisTotalAmount>{fmt_amount(totals["tax_basis_total_ht"])}</ram:TaxBasisTotalAmount>',
        f'        <ram:TaxTotalAmount currencyID="{_xml_escape(currency)}">{fmt_amount(totals["tax_total_amount"])}</ram:TaxTotalAmount>',
        f'        <ram:GrandTotalAmount>{fmt_amount(totals["grand_total_ttc"])}</ram:GrandTotalAmount>',
    ])
    if totals["prepaid_amount"] > Decimal("0.00") and prof_key != "MINIMUM":
        xml_lines.append(f'        <ram:TotalPrepaidAmount>{fmt_amount(totals["prepaid_amount"])}</ram:TotalPrepaidAmount>')
    xml_lines.extend([
        f'        <ram:DuePayableAmount>{fmt_amount(totals["due_payable_amount"])}</ram:DuePayableAmount>',
        '      </ram:SpecifiedTradeSettlementHeaderMonetarySummation>',
        '    </ram:ApplicableHeaderTradeSettlement>',
        '  </rsm:SupplyChainTradeTransaction>',
        '</rsm:CrossIndustryInvoice>',
    ])

    xml_str = "\n".join(xml_lines) + "\n"
    # Vérification immédiate que le XML produit est bien formé
    ET.fromstring(xml_str.encode("utf-8"))
    return xml_str.encode("utf-8")


# ---------------------------------------------------------------------------
# Générateur PDF/A-3B Hybride avec Pièce Jointe `factur-x.xml` (Zéro dépendance)
# ---------------------------------------------------------------------------

def _encode_winansi_pdf_literal(text: str) -> str:
    """
    Encode une chaîne Unicode en littéral PDF `(...)` utilisant WinAnsiEncoding (Windows-1252),
    garantissant le rendu natif de tous les accents français (é è ê à ç œ...) et du symbole € (0x80).
    """
    out: List[str] = ["("]
    for ch in str(text or ""):
        code = ord(ch)
        if code in CP1252_EXTRA_MAP:
            b = CP1252_EXTRA_MAP[code]
        elif 0x20 <= code <= 0x7E:
            b = code
        elif 0xA0 <= code <= 0xFF:
            b = code
        else:
            b = ord("?")

        if b in (0x28, 0x29, 0x5C):  # ( ) \
            out.append("\\" + chr(b))
        elif 0x20 <= b <= 0x7E:
            out.append(chr(b))
        else:
            out.append(f"\\{b:03o}")
    out.append(")")
    return "".join(out)


def _wrap_text(text: str, max_chars: int) -> List[str]:
    words = str(text or "").split()
    if not words:
        return [""]
    lines: List[str] = []
    cur = words[0]
    for w in words[1:]:
        if len(cur) + 1 + len(w) <= max_chars:
            cur += " " + w
        else:
            lines.append(cur)
            cur = w
    lines.append(cur)
    return lines


def _build_xmp_metadata(inv_number: str, xmp_level: str, now_iso: str) -> bytes:
    xmp = f"""<?xpacket begin="\ufeff" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/">
  <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
    <rdf:Description rdf:about="" xmlns:pdfaid="http://www.aiim.org/pdfa/ns/id/">
      <pdfaid:part>3</pdfaid:part>
      <pdfaid:conformance>B</pdfaid:conformance>
    </rdf:Description>
    <rdf:Description rdf:about="" xmlns:dc="http://purl.org/dc/elements/1.1/">
      <dc:title>
        <rdf:Alt>
          <rdf:li xml:lang="x-default">Facture { _xml_escape(inv_number) } (Factur-X)</rdf:li>
        </rdf:Alt>
      </dc:title>
      <dc:creator>
        <rdf:Seq>
          <rdf:li>Studio Factur-X Local 2027</rdf:li>
        </rdf:Seq>
      </dc:creator>
    </rdf:Description>
    <rdf:Description rdf:about="" xmlns:xmp="http://ns.adobe.com/xap/1.0/">
      <xmp:CreatorTool>Studio Factur-X Local 2027</xmp:CreatorTool>
      <xmp:CreateDate>{now_iso}</xmp:CreateDate>
      <xmp:ModifyDate>{now_iso}</xmp:ModifyDate>
    </rdf:Description>
    <rdf:Description rdf:about=""
        xmlns:pdfaExtension="http://www.aiim.org/pdfa/ns/extension/"
        xmlns:pdfaSchema="http://www.aiim.org/pdfa/ns/schema#"
        xmlns:pdfaProperty="http://www.aiim.org/pdfa/ns/property#">
      <pdfaExtension:schemas>
        <rdf:Bag>
          <rdf:li rdf:parseType="Resource">
            <pdfaSchema:schema>Factur-X PDFA Extension Schema</pdfaSchema:schema>
            <pdfaSchema:namespaceURI>urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#</pdfaSchema:namespaceURI>
            <pdfaSchema:prefix>fx</pdfaSchema:prefix>
            <pdfaSchema:property>
              <rdf:Seq>
                <rdf:li rdf:parseType="Resource">
                  <pdfaProperty:name>DocumentFileName</pdfaProperty:name>
                  <pdfaProperty:valueType>Text</pdfaProperty:valueType>
                  <pdfaProperty:category>external</pdfaProperty:category>
                  <pdfaProperty:description>The name of the embedded XML document</pdfaProperty:description>
                </rdf:li>
                <rdf:li rdf:parseType="Resource">
                  <pdfaProperty:name>DocumentType</pdfaProperty:name>
                  <pdfaProperty:valueType>Text</pdfaProperty:valueType>
                  <pdfaProperty:category>external</pdfaProperty:category>
                  <pdfaProperty:description>The type of the hybrid document</pdfaProperty:description>
                </rdf:li>
                <rdf:li rdf:parseType="Resource">
                  <pdfaProperty:name>Version</pdfaProperty:name>
                  <pdfaProperty:valueType>Text</pdfaProperty:valueType>
                  <pdfaProperty:category>external</pdfaProperty:category>
                  <pdfaProperty:description>The actual version of the Factur-X XML schema</pdfaProperty:description>
                </rdf:li>
                <rdf:li rdf:parseType="Resource">
                  <pdfaProperty:name>ConformanceLevel</pdfaProperty:name>
                  <pdfaProperty:valueType>Text</pdfaProperty:valueType>
                  <pdfaProperty:category>external</pdfaProperty:category>
                  <pdfaProperty:description>The conformance level of the embedded Factur-X data</pdfaProperty:description>
                </rdf:li>
              </rdf:Seq>
            </pdfaSchema:property>
          </rdf:li>
        </rdf:Bag>
      </pdfaExtension:schemas>
    </rdf:Description>
    <rdf:Description rdf:about="" xmlns:fx="urn:factur-x:pdfa:CrossIndustryDocument:invoice:1p0#">
      <fx:DocumentType>INVOICE</fx:DocumentType>
      <fx:DocumentFileName>factur-x.xml</fx:DocumentFileName>
      <fx:Version>1.0</fx:Version>
      <fx:ConformanceLevel>{_xml_escape(xmp_level)}</fx:ConformanceLevel>
    </rdf:Description>
  </rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>"""
    return xmp.encode("utf-8")


class _PageCanvas:
    """Constructeur léger de commandes graphiques PDF (format A4 : 595.28 x 841.89 pt)."""

    def __init__(self) -> None:
        self.cmds: List[str] = []

    def rect_fill(self, x: float, y: float, w: float, h: float, rgb: Tuple[float, float, float]) -> None:
        r, g, b = rgb
        self.cmds.append(f"q {r:.3f} {g:.3f} {b:.3f} rg {x:.2f} {y:.2f} {w:.2f} {h:.2f} re f Q")

    def rect_stroke(self, x: float, y: float, w: float, h: float, rgb: Tuple[float, float, float], lw: float = 0.75) -> None:
        r, g, b = rgb
        self.cmds.append(f"q {lw:.2f} w {r:.3f} {g:.3f} {b:.3f} RG {x:.2f} {y:.2f} {w:.2f} {h:.2f} re S Q")

    def line(self, x1: float, y1: float, x2: float, y2: float, rgb: Tuple[float, float, float], lw: float = 0.6) -> None:
        r, g, b = rgb
        self.cmds.append(f"q {lw:.2f} w {r:.3f} {g:.3f} {b:.3f} RG {x1:.2f} {y1:.2f} m {x2:.2f} {y2:.2f} l S Q")

    def text(
        self,
        x: float,
        y: float,
        txt: str,
        font: str = "F1",
        size: float = 9.5,
        rgb: Tuple[float, float, float] = (0.06, 0.09, 0.16),
        align: str = "left",
    ) -> None:
        s = str(txt or "")
        if align in ("right", "center"):
            # Estimation métrique Helvetica précise pour alignement droit des montants
            avg_factor = 0.54 if font == "F2" else 0.51
            est_w = len(s) * size * avg_factor
            if align == "right":
                x -= est_w
            else:
                x -= est_w / 2.0
        r, g, b = rgb
        lit = _encode_winansi_pdf_literal(s)
        self.cmds.append(f"BT /{font} {size:.2f} Tf {r:.3f} {g:.3f} {b:.3f} rg 1 0 0 1 {x:.2f} {y:.2f} Tm {lit} Tj ET")

    def to_bytes(self) -> bytes:
        return ("\n".join(self.cmds) + "\n").encode("latin-1")


def build_facturx_pdf(
    invoice: Dict[str, Any],
    xml_bytes: Optional[bytes] = None,
    profile: str = "BASIC",
) -> bytes:
    """
    Génère un PDF 1.7 / PDF/A-3B hybride complet embarquant `factur-x.xml`
    en pièce jointe (`/EmbeddedFiles` + `/AF`) et affichant la facture B2B en haute lisibilité.
    """
    prof_key = normalize_profile(profile or invoice.get("profile", "BASIC"))
    prof = PROFILES[prof_key]
    if xml_bytes is None:
        xml_bytes = build_facturx_xml(invoice, profile=prof_key)

    totals = compute_invoice_totals(invoice)
    seller = invoice["seller"]
    buyer = invoice["buyer"]
    currency = str(invoice.get("currency", "EUR")).upper()

    doc_type = str(invoice.get("doc_type", "380")).strip()
    doc_label = (
        "AVOIR" if doc_type == "381"
        else ("DEVIS COMMERCIAL" if doc_type in ("DEVIS", "325") else "FACTURE")
    )
    inv_number = str(invoice["number"]).strip()
    issue_fr = format_date_fr(invoice.get("issue_date", ""))
    delivery_fr = format_date_fr(invoice.get("delivery_date") or invoice.get("issue_date") or "")
    due_fr = format_date_fr(invoice.get("due_date") or invoice.get("issue_date") or "")
    op_label = OPERATION_NATURES.get(
        str(invoice.get("operation_nature", "Prestation de services")).strip(),
        str(invoice.get("operation_nature", "Prestation de services")).strip(),
    )

    # Palette sobre B2B Fintech
    C_NAVY = (0.06, 0.09, 0.16)       # #0F172A
    C_PRIMARY = (0.12, 0.25, 0.69)    # #1E40AF
    C_MUTED = (0.39, 0.45, 0.55)      # #64748B
    C_LIGHT_BG = (0.97, 0.98, 0.99)   # #F8FAFC
    C_BORDER = (0.86, 0.89, 0.93)     # #DBE4EE
    C_BADGE_BG = (0.93, 0.96, 1.00)   # #EFF6FF
    C_WHITE = (1.0, 1.0, 1.0)

    # Pagination automatique des lignes (max ~10 lignes sur page 1, ~18 sur pages suivantes)
    all_lines = totals["lines"]
    chunks: List[List[Dict[str, Any]]] = []
    if len(all_lines) <= 10:
        chunks.append(all_lines)
    else:
        chunks.append(all_lines[:10])
        rest = all_lines[10:]
        while rest:
            chunks.append(rest[:16])
            rest = rest[16:]

    pages_bytes: List[bytes] = []
    total_pages = len(chunks)

    for page_idx, page_lines in enumerate(chunks, start=1):
        cv = _PageCanvas()
        # Bandeau supérieur institutionnel
        cv.rect_fill(0, 772, 595.28, 70, C_NAVY)
        seller_title = str(seller["name"]).strip()
        if seller.get("is_ei") and "ei" not in seller_title.lower():
            seller_title += " (EI)"
        cv.text(40, 814, seller_title, font="F2", size=14, rgb=C_WHITE)
        cv.text(
            40,
            796,
            f"SIREN/SIRET : {seller.get('siret') or seller.get('siren')}  •  Conformité Factur-X {prof['xmp_level']} (EN 16931)",
            font="F1",
            size=8.5,
            rgb=(0.75, 0.82, 0.94),
        )
        cv.text(555, 814, f"{doc_label} N° {inv_number}", font="F2", size=13.5, rgb=C_WHITE, align="right")
        cv.text(555, 796, f"Date d'émission : {issue_fr}  •  Page {page_idx}/{total_pages}", font="F1", size=8.5, rgb=(0.75, 0.82, 0.94), align="right")

        y_cursor = 748.0

        if page_idx == 1:
            # Bloc Émetteur & Bloc Destinataire (hauteur confortable 112pt avec word-wrap)
            cv.rect_fill(40, 628, 248, 112, C_LIGHT_BG)
            cv.rect_stroke(40, 628, 248, 112, C_BORDER)
            cv.text(50, 725, "ÉMETTEUR", font="F2", size=8, rgb=C_PRIMARY)
            sy = 711.0
            for st_line in _wrap_text(seller_title, 38)[:2]:
                cv.text(50, sy, st_line, font="F2", size=9.2, rgb=C_NAVY)
                sy -= 11.5
            for info_line in [
                str(seller.get("address", "")),
                f"{seller.get('postal_code', '')} {seller.get('city', '')} ({seller.get('country', 'FR')})".strip(),
                f"SIREN/SIRET : {seller.get('siret') or seller.get('siren')}",
                f"TVA : {seller.get('vat_number') or ('Franchise art. 293 B CGI' if totals['is_franchise'] else compute_french_vat(seller.get('siret') or seller.get('siren')))}",
                str(seller.get("email") or ""),
            ]:
                if info_line.strip():
                    for wline in _wrap_text(info_line.strip(), 45)[:2]:
                        if sy >= 634.0:
                            cv.text(50, sy, wline, font="F1", size=8.1, rgb=C_MUTED)
                            sy -= 11.0

            cv.rect_fill(307, 628, 248, 112, C_LIGHT_BG)
            cv.rect_stroke(307, 628, 248, 112, C_BORDER)
            buyer_tag = "CLIENT PROFESSIONNEL (B2B)" if buyer.get("is_b2b", True) else "CLIENT PARTICULIER (B2C)"
            cv.text(317, 725, buyer_tag, font="F2", size=8, rgb=C_PRIMARY)
            by = 711.0
            for bt_line in _wrap_text(str(buyer.get("name", "")), 38)[:2]:
                cv.text(317, by, bt_line, font="F2", size=9.2, rgb=C_NAVY)
                by -= 11.5
            for b_line in [
                str(buyer.get("address", "")),
                f"{buyer.get('postal_code', '')} {buyer.get('city', '')} ({buyer.get('country', 'FR')})".strip(),
                f"SIREN/SIRET Client : {buyer.get('siret') or buyer.get('siren') or 'Non applicable (B2C)'}",
                (f"TVA Client : {buyer['vat_number']}" if buyer.get("vat_number") else ""),
                (f"Réf. commande : {invoice['order_reference']}" if invoice.get("order_reference") else ""),
            ]:
                if b_line.strip():
                    for wline in _wrap_text(b_line.strip(), 45)[:2]:
                        if by >= 634.0:
                            cv.text(317, by, wline, font="F1", size=8.1, rgb=C_MUTED)
                            by -= 11.0

            # Barre Mentions Obligatoires 2026-2027 (Nature opération, Date prestation, Échéance, Livraison)
            delivery_addr = invoice.get("delivery_address") or {}
            deliv_txt = (
                f"Livraison : {delivery_addr.get('address', '')}, {delivery_addr.get('postal_code', '')} {delivery_addr.get('city', '')}".strip(", ")
                if delivery_addr and (delivery_addr.get("address") or delivery_addr.get("city"))
                else "Adresse de livraison : identique à l'adresse de facturation"
            )
            sub_banner_lines = _wrap_text(f"Date d'opération : {delivery_fr}  •  Échéance : {due_fr}  •  {deliv_txt}", 98)
            banner_h = 24.0 + len(sub_banner_lines) * 10.5
            banner_bottom = 618.0 - banner_h
            cv.rect_fill(40, banner_bottom, 515, banner_h, C_BADGE_BG)
            cv.rect_stroke(40, banner_bottom, 515, banner_h, C_BORDER)
            cv.text(50, 618.0 - 13.0, f"Nature de l'opération : {op_label}", font="F2", size=8.5, rgb=C_PRIMARY)
            b_y = 618.0 - 24.5
            for sb_line in sub_banner_lines:
                cv.text(50, b_y, sb_line, font="F1", size=7.9, rgb=C_NAVY)
                b_y -= 10.0
            y_cursor = banner_bottom - 12.0

        # En-tête du tableau des lignes
        cv.rect_fill(40, y_cursor - 20, 515, 20, C_NAVY)
        cv.text(48, y_cursor - 13, "DÉSIGNATION DES BIENS OU PRESTATIONS", font="F2", size=8, rgb=C_WHITE)
        cv.text(330, y_cursor - 13, "QTÉ", font="F2", size=8, rgb=C_WHITE, align="right")
        cv.text(405, y_cursor - 13, "P.U. HT", font="F2", size=8, rgb=C_WHITE, align="right")
        cv.text(462, y_cursor - 13, "TVA", font="F2", size=8, rgb=C_WHITE, align="right")
        cv.text(547, y_cursor - 13, "TOTAL HT", font="F2", size=8, rgb=C_WHITE, align="right")
        y_cursor -= 20.0

        for row_i, item in enumerate(page_lines):
            title_lines = _wrap_text(item["title"], 44)
            desc_lines = _wrap_text(item["description"], 54) if item["description"] else []
            row_h = max(22.0, 9.0 + len(title_lines) * 10.5 + len(desc_lines) * 9.5)
            if row_i % 2 == 1:
                cv.rect_fill(40, y_cursor - row_h, 515, row_h, C_LIGHT_BG)
            cv.line(40, y_cursor - row_h, 555, y_cursor - row_h, C_BORDER, 0.5)

            ty = y_cursor - 12.5
            for tl in title_lines:
                cv.text(48, ty, tl, font="F2", size=8.4, rgb=C_NAVY)
                ty -= 10.5
            for dl in desc_lines:
                cv.text(48, ty, dl, font="F1", size=7.5, rgb=C_MUTED)
                ty -= 9.5

            qty_str = f"{item['quantity']:g} {item['unit']}"
            cv.text(330, y_cursor - 13, qty_str, font="F1", size=8.4, rgb=C_NAVY, align="right")
            cv.text(405, y_cursor - 13, fmt_fr_currency(item["net_unit_price_ht"], currency), font="F1", size=8.4, rgb=C_NAVY, align="right")
            tva_str = "Exon." if totals["is_franchise"] else f"{item['vat_rate']:.1f}%"
            cv.text(462, y_cursor - 13, tva_str, font="F1", size=8.4, rgb=C_MUTED, align="right")
            cv.text(547, y_cursor - 13, fmt_fr_currency(item["line_total_ht"], currency), font="F2", size=8.6, rgb=C_NAVY, align="right")
            y_cursor -= row_h

        if page_idx == total_pages:
            # Totaux & Règlement sur la dernière page
            y_tot = min(y_cursor - 16.0, 310.0)

            # Colonne gauche : Règlement & Ventilation TVA (word-wrap complet sans coupure)
            cv.text(40, y_tot, "MODALITÉS DE RÈGLEMENT", font="F2", size=8.5, rgb=C_PRIMARY)
            pay_y = y_tot - 13.0
            iban_disp = seller.get("iban") or "Règlement par virement bancaire ou selon accord contractuel."
            for p_line in _wrap_text(f"Coord. règlement : {iban_disp}", 58):
                cv.text(40, pay_y, p_line, font="F1", size=8.1, rgb=C_NAVY)
                pay_y -= 10.5
            if seller.get("bic"):
                cv.text(40, pay_y, f"BIC : {seller['bic']}", font="F1", size=8.1, rgb=C_NAVY)
                pay_y -= 10.5
            pay_y -= 3.0
            for tb in totals["tax_breakdown"]:
                lbl = (
                    f"Base exonérée art. 293 B CGI : {fmt_fr_currency(tb['basis_amount'], currency)}"
                    if totals["is_franchise"]
                    else f"Base HT ({tb['rate']:.1f}%) : {fmt_fr_currency(tb['basis_amount'], currency)}  ->  TVA : {fmt_fr_currency(tb['tax_amount'], currency)}"
                )
                for tb_line in _wrap_text(lbl, 60):
                    cv.text(40, pay_y, tb_line, font="F1", size=7.9, rgb=C_MUTED)
                    pay_y -= 10.5

            # Carte récapitulative droite (Total HT / TVA / Net à payer TTC)
            cv.rect_fill(345, y_tot - 74, 210, 84, C_LIGHT_BG)
            cv.rect_stroke(345, y_tot - 74, 210, 84, C_BORDER)
            cv.text(355, y_tot - 8, "Total HT", font="F1", size=9, rgb=C_MUTED)
            cv.text(545, y_tot - 8, fmt_fr_currency(totals["tax_basis_total_ht"], currency), font="F2", size=9, rgb=C_NAVY, align="right")

            tva_label = "TVA (Franchise 293 B)" if totals["is_franchise"] else "Total TVA"
            cv.text(355, y_tot - 25, tva_label, font="F1", size=9, rgb=C_MUTED)
            cv.text(545, y_tot - 25, fmt_fr_currency(totals["tax_total_amount"], currency), font="F2", size=9, rgb=C_NAVY, align="right")

            cv.rect_fill(345, y_tot - 74, 210, 34, C_PRIMARY)
            cv.text(355, y_tot - 61, "NET À PAYER TTC", font="F2", size=10, rgb=C_WHITE)
            cv.text(545, y_tot - 61, fmt_fr_currency(totals["due_payable_amount"], currency), font="F2", size=11.5, rgb=C_WHITE, align="right")

        # Pied de page légal obligatoire sur chaque page (word-wrap aux espaces)
        cv.line(40, 118, 555, 118, C_BORDER, 0.75)
        vat_footer = (
            "TVA non applicable, article 293 B du Code général des impôts (Franchise en base de TVA)."
            if totals["is_franchise"]
            else (
                "Option pour le paiement de la taxe d'après les débits."
                if totals["vat_regime"] == "TVA_DEBITS"
                else "TVA acquittée sur les encaissements (prestations de services) sauf mention contraire."
            )
        )
        penalties_paragraph = (
            "Pas d'escompte pour paiement anticipé. En cas de retard de paiement, application de pénalités égales à 3 fois le taux d'intérêt légal "
            "exigibles de plein droit dès le lendemain de l'échéance, et d'une indemnité forfaitaire pour frais de recouvrement de 40,00 € (art. L441-10 et D441-5 C. com.)."
        )
        legal_lines: List[str] = []
        legal_lines.extend(_wrap_text(vat_footer, 116))
        legal_lines.extend(_wrap_text(penalties_paragraph, 116))
        legal_lines.extend(_wrap_text(f"Document Factur-X 1.0.07 hybride conforme EN 16931 — Pièce jointe structurée embarquée : factur-x.xml (Profil {prof['xmp_level']}).", 116))
        fy = 105.0
        for ll in legal_lines:
            cv.text(40, fy, ll, font="F1", size=7.1, rgb=C_MUTED)
            fy -= 9.8

        pages_bytes.append(cv.to_bytes())

    # Assemblage des objets PDF 1.7 / PDF/A-3B
    now = dt.datetime.now()
    pdf_date = now.strftime("D:%Y%m%d%H%M%S+01'00'")
    iso_date = now.strftime("%Y-%m-%dT%H:%M:%S+01:00")

    compressed_xml = zlib.compress(xml_bytes, level=9)
    xml_md5 = hashlib.md5(xml_bytes).hexdigest()
    xmp_bytes = _build_xmp_metadata(inv_number, prof["xmp_level"], iso_date)

    # Réservation des numéros d'objets :
    # 1: Catalog
    # 2: Pages
    # 3: Font F1 (Helvetica WinAnsiEncoding)
    # 4: Font F2 (Helvetica-Bold WinAnsiEncoding)
    # 5: EmbeddedFiles NameTree
    # 6: Filespec (factur-x.xml)
    # 7: EmbeddedFile stream (factur-x.xml compressé FlateDecode)
    # 8: XMP Metadata stream (non compressé conformément à PDF/A)
    # 9.. : Page objects & Content streams
    objects: Dict[int, bytes] = {}

    objects[3] = b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"
    objects[4] = b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"
    objects[5] = b"<< /Names [ (factur-x.xml) 6 0 R ] >>"
    objects[6] = (
        b"<< /Type /Filespec /F (factur-x.xml) /UF (factur-x.xml) "
        b"/Desc (Factur-X EN 16931 CII Invoice XML) /AFRelationship /Data "
        b"/EF << /F 7 0 R /UF 7 0 R >> >>"
    )
    ef_header = (
        f"<< /Type /EmbeddedFile /Subtype /text#2Fxml /Filter /FlateDecode "
        f"/Length {len(compressed_xml)} "
        f"/Params << /Size {len(xml_bytes)} /CreationDate ({pdf_date}) /ModDate ({pdf_date}) /CheckSum <{xml_md5}> >> >>\nstream\n"
    ).encode("ascii")
    objects[7] = ef_header + compressed_xml + b"\nendstream"

    xmp_header = f"<< /Type /Metadata /Subtype /XML /Length {len(xmp_bytes)} >>\nstream\n".encode("ascii")
    objects[8] = xmp_header + xmp_bytes + b"\nendstream"

    next_obj_id = 9
    page_obj_ids: List[int] = []
    for p_content in pages_bytes:
        p_id = next_obj_id
        c_id = next_obj_id + 1
        next_obj_id += 2
        page_obj_ids.append(p_id)

        comp_content = zlib.compress(p_content, level=6)
        objects[c_id] = (
            f"<< /Filter /FlateDecode /Length {len(comp_content)} >>\nstream\n".encode("ascii")
            + comp_content
            + b"\nendstream"
        )
        objects[p_id] = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] "
            f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> "
            f"/Contents {c_id} 0 R >>"
        ).encode("ascii")

    kids_refs = " ".join(f"{pid} 0 R" for pid in page_obj_ids)
    objects[2] = f"<< /Type /Pages /Count {len(page_obj_ids)} /Kids [ {kids_refs} ] >>".encode("ascii")
    objects[1] = (
        b"<< /Type /Catalog /Pages 2 0 R "
        b"/Names << /EmbeddedFiles 5 0 R >> "
        b"/AF [ 6 0 R ] "
        b"/Metadata 8 0 R "
        b"/Lang (fr-FR) >>"
    )

    info_id = next_obj_id
    objects[info_id] = (
        f"<< /Title {_encode_winansi_pdf_literal(f'{doc_label} {inv_number}').encode('latin-1').decode('latin-1')} "
        f"/Producer (Studio Factur-X Local 2027) "
        f"/Creator (Studio Factur-X Local 2027) "
        f"/CreationDate ({pdf_date}) /ModDate ({pdf_date}) >>"
    ).encode("latin-1")

    max_id = info_id
    out_chunks: List[bytes] = [b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n"]
    offsets: Dict[int, int] = {}
    cursor = len(out_chunks[0])

    for oid in range(1, max_id + 1):
        offsets[oid] = cursor
        block = f"{oid} 0 obj\n".encode("ascii") + objects[oid] + b"\nendobj\n"
        out_chunks.append(block)
        cursor += len(block)

    xref_offset = cursor
    xref_lines = [f"xref\n0 {max_id + 1}\n", "0000000000 65535 f \n"]
    for oid in range(1, max_id + 1):
        xref_lines.append(f"{offsets[oid]:010d} 00000 n \n")

    file_id_hex = hashlib.md5(xml_bytes + pdf_date.encode("ascii")).hexdigest()
    trailer = (
        f"trailer\n<< /Size {max_id + 1} /Root 1 0 R /Info {info_id} 0 R /ID [<{file_id_hex}> <{file_id_hex}>] >>\n"
        f"startxref\n{xref_offset}\n%%EOF\n"
    ).encode("ascii")

    out_chunks.append("".join(xref_lines).encode("ascii"))
    out_chunks.append(trailer)
    return b"".join(out_chunks)


# ---------------------------------------------------------------------------
# Extracteur & Vérificateur Factur-X (PDF/A-3 + XML CII)
# ---------------------------------------------------------------------------

def _decompress_pdf_stream(raw_stream: bytes, dict_header: bytes) -> bytes:
    is_flate = (b"/FlateDecode" in dict_header) or (b"/Fl" in dict_header)
    if not is_flate:
        return raw_stream
    for wbits in (zlib.MAX_WBITS, -zlib.MAX_WBITS):
        try:
            return zlib.decompress(raw_stream, wbits)
        except zlib.error:
            try:
                return zlib.decompress(raw_stream.strip(b"\r\n"), wbits)
            except zlib.error:
                continue
    return raw_stream


def extract_facturx_xml_from_pdf(pdf_bytes: bytes) -> Tuple[Optional[bytes], Dict[str, Any]]:
    """
    Extrait la pièce jointe XML Factur-X (`factur-x.xml` / ZUGFeRD / XRechnung)
    depuis un fichier PDF binaire (supporte FlateDecode et flux non compressés).
    """
    meta = {
        "has_embedded_files": b"/EmbeddedFiles" in pdf_bytes,
        "has_af_tag": b"/AF" in pdf_bytes,
        "has_pdfa_xmp": b"pdfaid:part" in pdf_bytes,
        "has_facturx_xmp": b"CrossIndustryDocument:invoice" in pdf_bytes or b"fx:ConformanceLevel" in pdf_bytes,
        "filename": None,
    }

    # Indexation de tous les objets PDF `N 0 obj ... endobj`
    obj_pattern = re.compile(rb"(\d+)\s+\d+\s+obj\b(.*?)endobj", re.DOTALL)
    objects_raw: Dict[int, bytes] = {}
    for m in obj_pattern.finditer(pdf_bytes):
        objects_raw[int(m.group(1))] = m.group(2)

    stream_pattern = re.compile(rb"(<<.*?>>)\s*stream(?:\r\n|\n)(.*?)(?:\r\n|\n)?endstream", re.DOTALL)

    # Décompression éventuelle des Object Streams PDF 1.5+ (/Type /ObjStm)
    for body in list(objects_raw.values()):
        sm = stream_pattern.search(body)
        if sm and b"/ObjStm" in sm.group(1):
            unpacked = _decompress_pdf_stream(sm.group(2), sm.group(1))
            first_m = re.search(rb"/First\s+(\d+)", sm.group(1))
            if first_m and b"CrossIndustryInvoice" in unpacked:
                idx = unpacked.find(b"<?xml")
                if idx != -1:
                    meta["filename"] = "factur-x.xml"
                    return unpacked[idx:], meta

    # Stratégie 1 : Recherche explicite via dictionnaire /Filespec -> /EF << /F X 0 R >>
    filespec_re = re.compile(
        rb"/F(?:ilespec)?\b.*?/(?:UF|F)\s*\(([^)]+\.xml)\).*?/EF\s*<<[^>]*/F\s+(\d+)\s+\d+\s+R",
        re.DOTALL | re.IGNORECASE,
    )
    for body in objects_raw.values():
        fm = filespec_re.search(body)
        if fm:
            fname = fm.group(1).decode("latin-1", errors="replace")
            ef_obj_id = int(fm.group(2))
            meta["filename"] = fname
            if ef_obj_id in objects_raw:
                sm = stream_pattern.search(objects_raw[ef_obj_id])
                if sm:
                    xml_candidate = _decompress_pdf_stream(sm.group(2), sm.group(1))
                    if b"CrossIndustryInvoice" in xml_candidate or b"Invoice" in xml_candidate:
                        return xml_candidate.strip(), meta

    # Stratégie 2 : Balayage de tous les flux PDF (compressés ou non)
    for sm in stream_pattern.finditer(pdf_bytes):
        header, raw_s = sm.group(1), sm.group(2)
        candidate = _decompress_pdf_stream(raw_s, header)
        if b"CrossIndustryInvoice" in candidate:
            start = candidate.find(b"<?xml")
            if start == -1:
                start = candidate.find(b"<rsm:CrossIndustryInvoice")
            if start == -1:
                start = candidate.find(b"<CrossIndustryInvoice")
            if start != -1:
                meta["filename"] = meta["filename"] or "factur-x.xml"
                return candidate[start:].strip(), meta

    return None, meta


def _find_text(elem: Optional[ET.Element], path: str, ns: Dict[str, str]) -> str:
    if elem is None:
        return ""
    found = elem.find(path, ns)
    return (found.text or "").strip() if found is not None else ""


def inspect_facturx_bytes(data: bytes, source_name: str = "document") -> Dict[str, Any]:
    """
    Contrôle complet d'un fichier PDF Factur-X ou XML CII reçu ou émis :
    conformité conteneur PDF/A-3, syntaxe XML, profil EN 16931, SIREN Luhn, totaux, mentions 2026-2027.
    """
    is_pdf = data.lstrip().startswith(b"%PDF-")
    checks: List[Dict[str, Any]] = []
    errors: List[str] = []
    warnings: List[str] = []
    pdf_meta: Dict[str, Any] = {}

    if is_pdf:
        xml_bytes, pdf_meta = extract_facturx_xml_from_pdf(data)
        checks.append({
            "id": "pdf_embedded",
            "label": "Pièce jointe XML Factur-X présente dans /EmbeddedFiles",
            "passed": xml_bytes is not None and pdf_meta.get("has_embedded_files", False),
        })
        checks.append({
            "id": "pdf_af",
            "label": "Balise PDF/A-3 Associated Files (/AF) présente",
            "passed": bool(pdf_meta.get("has_af_tag")),
        })
        checks.append({
            "id": "pdf_xmp",
            "label": "Métadonnées XMP PDF/A-3 & extension Factur-X présentes",
            "passed": bool(pdf_meta.get("has_pdfa_xmp") and pdf_meta.get("has_facturx_xmp")),
        })
        if xml_bytes is None:
            errors.append("Aucun fichier XML Factur-X (factur-x.xml) n'a été trouvé en pièce jointe de ce PDF.")
            return {
                "source": source_name,
                "is_pdf": True,
                "valid": False,
                "score": 15,
                "pdf_metadata": pdf_meta,
                "checks": checks,
                "errors": errors,
                "warnings": warnings,
                "summary": {},
                "xml_content": "",
            }
    else:
        xml_bytes = data

    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as exc:
        errors.append(f"XML mal formé (erreur syntaxique) : {exc}")
        return {
            "source": source_name,
            "is_pdf": is_pdf,
            "valid": False,
            "score": 10,
            "pdf_metadata": pdf_meta,
            "checks": checks,
            "errors": errors,
            "warnings": warnings,
            "summary": {},
            "xml_content": xml_bytes.decode("utf-8", errors="replace"),
        }

    ns = {"rsm": NS_RSM, "ram": NS_RAM, "udt": NS_UDT, "qdt": NS_QDT}
    is_cii_root = root.tag.endswith("CrossIndustryInvoice")
    checks.append({
        "id": "xml_root_cii",
        "label": "Racine UN/CEFACT rsm:CrossIndustryInvoice conforme",
        "passed": is_cii_root,
    })
    if not is_cii_root:
        errors.append(f"Balise racine inattendue : {root.tag} (attendu rsm:CrossIndustryInvoice).")

    profile_urn = _find_text(
        root,
        ".//rsm:ExchangedDocumentContext/ram:GuidelineSpecifiedDocumentContextParameter/ram:ID",
        ns,
    )
    known_urns = {v["urn"]: k for k, v in PROFILES.items()}
    detected_profile = known_urns.get(profile_urn, "CUSTOM" if profile_urn else "MISSING")
    checks.append({
        "id": "profile_urn",
        "label": f"Profil Factur-X / EN 16931 identifié ({detected_profile})",
        "passed": bool(profile_urn),
    })
    if not profile_urn:
        errors.append("Profil GuidelineSpecifiedDocumentContextParameter/ram:ID manquant.")

    doc_id = _find_text(root, ".//rsm:ExchangedDocument/ram:ID", ns)
    type_code = _find_text(root, ".//rsm:ExchangedDocument/ram:TypeCode", ns)
    issue_date = _find_text(root, ".//rsm:ExchangedDocument/ram:IssueDateTime/udt:DateTimeString", ns)
    checks.append({
        "id": "doc_header",
        "label": "Numéro de facture, TypeCode et Date d'émission (format 102) présents",
        "passed": bool(doc_id and type_code and len(issue_date) == 8 and issue_date.isdigit()),
    })
    if not doc_id:
        errors.append("Numéro de facture (ram:ID) manquant.")

    seller_elem = root.find(".//ram:ApplicableHeaderTradeAgreement/ram:SellerTradeParty", ns)
    buyer_elem = root.find(".//ram:ApplicableHeaderTradeAgreement/ram:BuyerTradeParty", ns)

    seller_name = _find_text(seller_elem, "ram:Name", ns)
    seller_siren = _find_text(seller_elem, "ram:SpecifiedLegalOrganization/ram:ID", ns)
    seller_vat = _find_text(seller_elem, "ram:SpecifiedTaxRegistration/ram:ID", ns)
    seller_country = _find_text(seller_elem, "ram:PostalTradeAddress/ram:CountryID", ns)

    seller_siren_ok = validate_siren(seller_siren) or validate_siret(seller_siren)
    checks.append({
        "id": "seller_siren_luhn",
        "label": f"SIREN/SIRET vendeur valide par Luhn ({seller_siren or 'absent'})",
        "passed": seller_siren_ok,
    })
    if not seller_siren_ok:
        errors.append(f"SIREN/SIRET vendeur manquant ou invalide au contrôle de Luhn ({seller_siren!r}).")

    buyer_name = _find_text(buyer_elem, "ram:Name", ns)
    buyer_siren = _find_text(buyer_elem, "ram:SpecifiedLegalOrganization/ram:ID", ns)
    buyer_siren_ok = bool(buyer_siren) and (validate_siren(buyer_siren) or validate_siret(buyer_siren))
    checks.append({
        "id": "buyer_siren_luhn",
        "label": f"SIREN/SIRET acheteur B2B présent & valide Luhn ({buyer_siren or 'absent'})",
        "passed": buyer_siren_ok,
    })
    if not buyer_siren:
        warnings.append("SIREN acheteur absent (acceptable uniquement si client particulier B2C ou étranger hors France).")
    elif not buyer_siren_ok:
        errors.append(f"SIREN/SIRET acheteur invalide au contrôle de Luhn ({buyer_siren!r}).")

    # Totaux monétaires & cohérence arithmétique
    settlement = root.find(".//ram:ApplicableHeaderTradeSettlement", ns)
    currency = _find_text(settlement, "ram:InvoiceCurrencyCode", ns)
    iban = _find_text(settlement, "ram:SpecifiedTradeSettlementPaymentMeans/ram:PayeePartyCreditorFinancialAccount/ram:IBANID", ns)
    sums = settlement.find("ram:SpecifiedTradeSettlementHeaderMonetarySummation", ns) if settlement is not None else None

    tax_basis = _find_text(sums, "ram:TaxBasisTotalAmount", ns)
    tax_total = _find_text(sums, "ram:TaxTotalAmount", ns)
    grand_total = _find_text(sums, "ram:GrandTotalAmount", ns)
    due_payable = _find_text(sums, "ram:DuePayableAmount", ns)

    math_ok = False
    if tax_basis and grand_total:
        tb_d = dec2(tax_basis)
        tt_d = dec2(tax_total or "0")
        gt_d = dec2(grand_total)
        math_ok = (tb_d + tt_d) == gt_d
        if not math_ok:
            errors.append(f"Incohérence arithmétique des totaux : HT ({tb_d}) + TVA ({tt_d}) != TTC ({gt_d}).")
    else:
        errors.append("Montants totaux obligatoires (TaxBasisTotalAmount / GrandTotalAmount) manquants.")

    checks.append({
        "id": "totals_math",
        "label": "Équilibre comptable strict (Base HT + TVA = Total TTC)",
        "passed": math_ok,
    })

    if iban:
        iban_ok = validate_iban(iban)
        checks.append({
            "id": "iban_mod97",
            "label": "Contrôle anti-fraude IBAN vendeur (clé Modulo-97)",
            "passed": iban_ok,
        })
        if not iban_ok:
            errors.append(f"IBAN vendeur invalide (risque d'erreur ou fraude au RIB) : {iban}")

    notes_elems = root.findall(".//rsm:ExchangedDocument/ram:IncludedNote/ram:Content", ns)
    notes_joined = " | ".join((n.text or "").strip() for n in notes_elems)
    line_elems = root.findall(".//ram:IncludedSupplyChainTradeLineItem", ns)

    passed_count = sum(1 for c in checks if c["passed"])
    score = int(round(100 * passed_count / max(len(checks), 1)))
    valid = len(errors) == 0

    return {
        "source": source_name,
        "is_pdf": is_pdf,
        "valid": valid,
        "score": score,
        "pdf_metadata": pdf_meta,
        "checks": checks,
        "errors": errors,
        "warnings": warnings,
        "summary": {
            "profile": detected_profile,
            "profile_urn": profile_urn,
            "invoice_number": doc_id,
            "type_code": type_code,
            "issue_date": f"{issue_date[6:8]}/{issue_date[4:6]}/{issue_date[0:4]}" if len(issue_date) == 8 else issue_date,
            "seller_name": seller_name,
            "seller_siren": seller_siren,
            "seller_vat": seller_vat,
            "seller_country": seller_country,
            "buyer_name": buyer_name,
            "buyer_siren": buyer_siren,
            "currency": currency,
            "tax_basis_ht": tax_basis,
            "tax_total": tax_total,
            "grand_total_ttc": grand_total,
            "due_payable": due_payable,
            "line_count": len(line_elems),
            "iban_present": bool(iban),
            "notes_preview": notes_joined[:240],
        },
        "xml_content": xml_bytes.decode("utf-8", errors="replace"),
    }


# ---------------------------------------------------------------------------
# Import Lot JSON / CSV & Génération d'Exemples Officiels
# ---------------------------------------------------------------------------

def load_invoices_from_csv(csv_path: Path) -> List[Dict[str, Any]]:
    """Charge un fichier CSV et regroupe automatiquement les lignes ayant le même `number`."""
    grouped: Dict[str, Dict[str, Any]] = {}
    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f, delimiter=";" if ";" in f.readline() else ",")
        f.seek(0)
        first_line = f.readline()
        delim = ";" if first_line.count(";") > first_line.count(",") else ","
        f.seek(0)
        reader = csv.DictReader(f, delimiter=delim)
        for row in reader:
            num = str(row.get("number") or row.get("invoice_number") or "").strip()
            if not num:
                continue
            if num not in grouped:
                grouped[num] = {
                    "number": num,
                    "doc_type": row.get("doc_type", "380").strip() or "380",
                    "issue_date": row.get("issue_date", "").strip(),
                    "delivery_date": row.get("delivery_date", "").strip() or row.get("issue_date", "").strip(),
                    "due_date": row.get("due_date", "").strip() or row.get("issue_date", "").strip(),
                    "operation_nature": row.get("operation_nature", "Prestation de services").strip(),
                    "order_reference": row.get("order_reference", "").strip(),
                    "profile": row.get("profile", "BASIC").strip() or "BASIC",
                    "seller": {
                        "name": row.get("seller_name", "").strip(),
                        "is_ei": str(row.get("seller_is_ei", "")).lower() in ("1", "true", "oui", "yes"),
                        "siren": row.get("seller_siren", "").strip(),
                        "address": row.get("seller_address", "").strip(),
                        "postal_code": row.get("seller_postal_code", "").strip(),
                        "city": row.get("seller_city", "").strip(),
                        "country": row.get("seller_country", "FR").strip() or "FR",
                        "vat_regime": row.get("vat_regime", "FRANCHISE_293B").strip() or "FRANCHISE_293B",
                        "email": row.get("seller_email", "").strip(),
                    },
                    "buyer": {
                        "name": row.get("buyer_name", "").strip(),
                        "is_b2b": str(row.get("buyer_is_b2b", "true")).lower() not in ("0", "false", "non", "no"),
                        "siren": row.get("buyer_siren", "").strip(),
                        "address": row.get("buyer_address", "").strip(),
                        "postal_code": row.get("buyer_postal_code", "").strip(),
                        "city": row.get("buyer_city", "").strip(),
                        "country": row.get("buyer_country", "FR").strip() or "FR",
                    },
                    "lines": [],
                }
            grouped[num]["lines"].append({
                "title": row.get("line_title", "Prestation").strip(),
                "quantity": row.get("line_qty", "1").strip(),
                "unit": row.get("line_unit", "jour").strip(),
                "unit_price_ht": row.get("line_unit_price_ht", "0").strip(),
                "vat_rate": row.get("line_vat_rate", "0").strip(),
            })
    return list(grouped.values())


def get_sample_invoices() -> List[Dict[str, Any]]:
    """Jeu d'essai B2B réaliste et 100% fictif (SIRENs valides Luhn INSEE)."""
    return [
        {
            "number": "FAC-2026-0104",
            "doc_type": "380",
            "profile": "BASIC",
            "issue_date": "2026-11-14",
            "delivery_date": "2026-11-12",
            "due_date": "2026-12-14",
            "operation_nature": "Prestation de services",
            "order_reference": "BC-2026-889",
            "buyer_reference": "DIRECTION-OPERATIONS",
            "seller": {
                "name": "Claire Moreau Conseil",
                "is_ei": True,
                "siren": "732829320",
                "address": "14 Rue de la République",
                "postal_code": "69002",
                "city": "Lyon",
                "country": "FR",
                "email": "contact@moreau-conseil-exemple.fr",
                "vat_regime": "FRANCHISE_293B",
            },
            "buyer": {
                "name": "Atelier Mécanique Rhodanien SAS",
                "is_b2b": True,
                "siren": "552100554",
                "address": "48 Avenue Jean Jaurès",
                "postal_code": "69007",
                "city": "Lyon",
                "country": "FR",
                "email": "comptabilite@amr-industrie-exemple.fr",
            },
            "lines": [
                {
                    "title": "Audit des flux de facturation électronique (Réforme sept. 2026 - sept. 2027)",
                    "details": "Cartographie des factures entrantes/sortantes et paramétrage du référentiel SIREN",
                    "quantity": 2,
                    "unit": "jour",
                    "unit_price_ht": "650.00",
                    "vat_rate": "0.00",
                },
                {
                    "title": "Formation opérationnelle équipe administrative (demi-journée)",
                    "details": "Contrôle des factures fournisseurs Factur-X et archivage à valeur probante",
                    "quantity": 1,
                    "unit": "forfait",
                    "unit_price_ht": "490.00",
                    "vat_rate": "0.00",
                },
            ],
        },
        {
            "number": "FAC-2026-0105",
            "doc_type": "380",
            "profile": "EN16931",
            "issue_date": "2026-11-14",
            "delivery_date": "2026-11-14",
            "due_date": "2026-12-14",
            "operation_nature": "Mixte",
            "order_reference": "CMD-4412",
            "seller": {
                "name": "Studio Graphique & Print Atlantique SAS",
                "is_ei": False,
                "siren": "443061841",
                "address": "8 Quai de la Fosse",
                "postal_code": "44000",
                "city": "Nantes",
                "country": "FR",
                "email": "facturation@sgpa-exemple.fr",
                "vat_regime": "TVA_DEBITS",
            },
            "buyer": {
                "name": "Boulangeries Réunies de l'Ouest SARL",
                "is_b2b": True,
                "siren": "732829320",
                "address": "22 Rue Crébillon",
                "postal_code": "44000",
                "city": "Nantes",
                "country": "FR",
            },
            "delivery_address": {
                "name": "Entrepôt Logistique Nord — Boulangeries de l'Ouest",
                "address": "15 Rue du Moulin de la Rousselière",
                "postal_code": "44800",
                "city": "Saint-Herblain",
                "country": "FR",
            },
            "lines": [
                {
                    "title": "Conception maquette signalétique magasin & charte 2027",
                    "quantity": 6,
                    "unit": "heure",
                    "unit_price_ht": "95.00",
                    "vat_rate": "20.00",
                },
                {
                    "title": "Livraison pack supports imprimés grand format (12 panneaux Dibond)",
                    "quantity": 12,
                    "unit": "unité",
                    "unit_price_ht": "42.50",
                    "vat_rate": "20.00",
                },
            ],
        },
    ]


# ---------------------------------------------------------------------------
# Interface Ligne de Commande (CLI)
# ---------------------------------------------------------------------------

def cmd_generate(args: argparse.Namespace) -> int:
    in_path = Path(args.input)
    out_dir = Path(args.outdir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if not in_path.exists():
        print(f"[ERREUR] Fichier introuvable : {in_path}", file=sys.stderr)
        return 1

    if in_path.suffix.lower() == ".csv":
        invoices = load_invoices_from_csv(in_path)
    else:
        raw = json.loads(in_path.read_text(encoding="utf-8"))
        if isinstance(raw, list):
            invoices = raw
        elif isinstance(raw, dict) and "invoices" in raw:
            invoices = raw["invoices"]
        else:
            invoices = [raw]

    if not invoices:
        print("[ERREUR] Aucune facture trouvée dans le fichier d'entrée.", file=sys.stderr)
        return 1

    manifest: List[Dict[str, Any]] = []
    for inv in invoices:
        prof = args.profile or inv.get("profile") or "BASIC"
        xml_bytes = build_facturx_xml(inv, profile=prof)
        pdf_bytes = build_facturx_pdf(inv, xml_bytes=xml_bytes, profile=prof)
        safe_num = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(inv["number"]))
        pdf_file = out_dir / f"{safe_num}_FacturX.pdf"
        xml_file = out_dir / f"{safe_num}_factur-x.xml"
        pdf_file.write_bytes(pdf_bytes)
        xml_file.write_bytes(xml_bytes)

        audit = inspect_facturx_bytes(pdf_bytes, source_name=pdf_file.name)
        manifest.append({
            "number": inv["number"],
            "profile": normalize_profile(prof),
            "pdf_file": str(pdf_file),
            "xml_file": str(xml_file),
            "pdf_size_bytes": len(pdf_bytes),
            "pdf_sha256": hashlib.sha256(pdf_bytes).hexdigest(),
            "audit_valid": audit["valid"],
            "audit_score": audit["score"],
        })
        print(f"[OK] {inv['number']} -> {pdf_file.name} ({len(pdf_bytes)} octets, audit {audit['score']}/100)")

    manifest_path = out_dir / "manifest_lot_facturx.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[LOT TERMINÉ] {len(manifest)} facture(s) générée(s) dans {out_dir}")
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    target = Path(args.target)
    if not target.exists():
        print(f"[ERREUR] Cible introuvable : {target}", file=sys.stderr)
        return 1

    files = (
        sorted([p for p in target.iterdir() if p.suffix.lower() in (".pdf", ".xml")])
        if target.is_dir()
        else [target]
    )
    results = [inspect_facturx_bytes(p.read_bytes(), source_name=p.name) for p in files]

    if args.json:
        clean_res = [{k: v for k, v in r.items() if k != "xml_content"} for r in results]
        print(json.dumps(clean_res, indent=2, ensure_ascii=False))
    else:
        for r in results:
            status = "CONFORME" if r["valid"] else "NON CONFORME"
            s = r.get("summary") or {}
            print(f"=== {r['source']} : {status} ({r['score']}/100) ===")
            if s:
                print(f"  Facture N° {s.get('invoice_number')} du {s.get('issue_date')} | Profil : {s.get('profile')}")
                print(f"  Émetteur : {s.get('seller_name')} (SIREN {s.get('seller_siren')})")
                print(f"  Client   : {s.get('buyer_name')} (SIREN {s.get('buyer_siren') or 'N/A'})")
                print(f"  Totaux   : HT {s.get('tax_basis_ht')} {s.get('currency')} | TVA {s.get('tax_total')} | TTC {s.get('grand_total_ttc')} {s.get('currency')}")
            for c in r["checks"]:
                mark = "[✓]" if c["passed"] else "[✗]"
                print(f"    {mark} {c['label']}")
            for e in r["errors"]:
                print(f"    [ERREUR] {e}")
            for w in r["warnings"]:
                print(f"    [AVIS]   {w}")

    return 0 if all(r["valid"] for r in results) else 1


def cmd_demo(args: argparse.Namespace) -> int:
    out_dir = Path(args.outdir)
    out_dir.mkdir(parents=True, exist_ok=True)
    samples = get_sample_invoices()

    # 1. Fichier JSON de lot exemple
    json_path = out_dir / "lot_factures_exemple.json"
    json_path.write_text(json.dumps({"invoices": samples}, indent=2, ensure_ascii=False), encoding="utf-8")

    # 2. Fichier CSV de lot exemple
    csv_path = out_dir / "lot_factures_exemple.csv"
    fieldnames = [
        "number", "doc_type", "profile", "issue_date", "due_date", "operation_nature", "order_reference",
        "seller_name", "seller_is_ei", "seller_siren", "seller_address", "seller_postal_code", "seller_city", "vat_regime",
        "buyer_name", "buyer_is_b2b", "buyer_siren", "buyer_address", "buyer_postal_code", "buyer_city",
        "line_title", "line_qty", "line_unit", "line_unit_price_ht", "line_vat_rate",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for inv in samples:
            for ln in inv["lines"]:
                writer.writerow({
                    "number": inv["number"],
                    "doc_type": inv["doc_type"],
                    "profile": inv["profile"],
                    "issue_date": inv["issue_date"],
                    "due_date": inv["due_date"],
                    "operation_nature": inv["operation_nature"],
                    "order_reference": inv.get("order_reference", ""),
                    "seller_name": inv["seller"]["name"],
                    "seller_is_ei": "true" if inv["seller"].get("is_ei") else "false",
                    "seller_siren": inv["seller"]["siren"],
                    "seller_address": inv["seller"]["address"],
                    "seller_postal_code": inv["seller"]["postal_code"],
                    "seller_city": inv["seller"]["city"],
                    "vat_regime": inv["seller"]["vat_regime"],
                    "buyer_name": inv["buyer"]["name"],
                    "buyer_is_b2b": "true",
                    "buyer_siren": inv["buyer"]["siren"],
                    "buyer_address": inv["buyer"]["address"],
                    "buyer_postal_code": inv["buyer"]["postal_code"],
                    "buyer_city": inv["buyer"]["city"],
                    "line_title": ln["title"],
                    "line_qty": ln["quantity"],
                    "line_unit": ln["unit"],
                    "line_unit_price_ht": ln["unit_price_ht"],
                    "line_vat_rate": ln["vat_rate"],
                })

    # 3. Facture PDF + XML officielle de démonstration
    primary = samples[0]
    xml_bytes = build_facturx_xml(primary, profile="BASIC")
    pdf_bytes = build_facturx_pdf(primary, xml_bytes=xml_bytes, profile="BASIC")
    (out_dir / "factur-x.xml").write_bytes(xml_bytes)
    (out_dir / "Facture_Exemple_FacturX_2027.pdf").write_bytes(pdf_bytes)
    print(f"[DEMO OK] Exemples générés dans {out_dir}")
    return 0


def cmd_check_siren(args: argparse.Namespace) -> int:
    code = 0
    for val in args.numbers:
        cleaned = clean_digits(val)
        if len(cleaned) == 9 and validate_siren(cleaned):
            print(f"[VALIDE] SIREN {cleaned} -> N° TVA intracommunautaire : {compute_french_vat(cleaned)}")
        elif len(cleaned) == 14 and validate_siret(cleaned):
            siren = cleaned[:9]
            print(f"[VALIDE] SIRET {cleaned} (SIREN {siren}) -> N° TVA intracommunautaire : {compute_french_vat(siren)}")
        else:
            print(f"[INVALIDE] {val} (échec longueur ou clé algorithmique de Luhn)")
            code = 1
    return code


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="facturx_cli.py",
        description="Studio Factur-X Local 2027 — Générateur & Vérificateur Factur-X (EN 16931 CII / PDF-A3)",
    )
    sub = p.add_subparsers(dest="command", required=True)

    p_gen = sub.add_parser("generate", help="Génère des factures PDF/Factur-X hybrides depuis un fichier JSON ou CSV")
    p_gen.add_argument("--input", "-i", required=True, help="Chemin du fichier .json ou .csv")
    p_gen.add_argument("--outdir", "-o", required=True, help="Dossier de sortie des fichiers PDF et XML")
    p_gen.add_argument("--profile", "-p", choices=["MINIMUM", "BASIC_WL", "BASIC", "EN16931"], help="Forcer un profil Factur-X")
    p_gen.set_defaults(func=cmd_generate)

    p_ver = sub.add_parser("verify", help="Extrait et vérifie une facture PDF Factur-X, un fichier XML ou un dossier")
    p_ver.add_argument("target", help="Chemin du fichier .pdf, .xml ou dossier à auditer")
    p_ver.add_argument("--json", action="store_true", help="Sortie au format JSON structuré")
    p_ver.set_defaults(func=cmd_verify)

    p_demo = sub.add_parser("demo", help="Génère un jeu d'exemples complets (PDF Factur-X, XML, JSON, CSV)")
    p_demo.add_argument("--outdir", "-o", default="./exemples", help="Dossier cible")
    p_demo.set_defaults(func=cmd_demo)

    p_sir = sub.add_parser("check-siren", help="Vérifie un ou plusieurs numéros SIREN/SIRET (Luhn) et calcule la TVA FR")
    p_sir.add_argument("numbers", nargs="+", help="Numéro(s) SIREN ou SIRET")
    p_sir.set_defaults(func=cmd_check_siren)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
