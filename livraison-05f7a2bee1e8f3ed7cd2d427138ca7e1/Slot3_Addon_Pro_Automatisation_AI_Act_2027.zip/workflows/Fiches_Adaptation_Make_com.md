# Fiches d'Adaptation Make.com (ex-Integromat) — Suite Opérations & Automatisation TPE 2027

Ces 3 fiches opérationnelles traduisent **module par module** les workflows n8n de la Suite Pro afin de les reproduire à l'identique sur **Make.com** (plan Core 9 USD/mois ou plan Free jusqu'à 1 000 opérations/mois, hébergement région `EU1.make.com` / `EU2.make.com` conforme RGPD).

---

## Fiche Make #1 — Tri Automatique des Factures Fournisseurs Factur-X & PDF

### Architecture Make (7 modules séquentiels + 1 Routeur)
1. **Trigger — `Email > Watch Emails` (ou `Google Drive > Watch Files in a Folder`)**
   - Critère : Emails non lus dans le dossier `Factures` avec pièces jointes (`Criteria: Unread`, `Mark message(s) as read: Yes`).
2. **Itérateur — `Flow Control > Iterator`**
   - Tableau source : `{{1.attachments[]}}`
   - Filtre à la sortie de l'itérateur : `lower(2.fileName)` se termine par `.pdf` ou `.xml`.
3. **Extraction XML / Texte — `XML > Parse XML` (ou `PDF.co / Dumpling AI / Google Cloud Vision` pour un PDF image)**
   - Si la pièce jointe est un XML Factur-X CII (ou extraite via script/module PDF), mappez :
     - `Num_Facture` : `{{3.CrossIndustryInvoice.ExchangedDocument.ID}}`
     - `Date_Brute` : `{{3.CrossIndustryInvoice.ExchangedDocument.IssueDateTime.DateTimeString}}`
     - `Fournisseur` : `{{3.CrossIndustryInvoice.SupplyChainTradeTransaction.ApplicableHeaderTradeAgreement.SellerTradeParty.Name}}`
     - `SIREN` : `{{3.CrossIndustryInvoice.SupplyChainTradeTransaction.ApplicableHeaderTradeAgreement.SellerTradeParty.SpecifiedLegalOrganization.ID}}`
     - `Montant_HT` : `{{3.CrossIndustryInvoice.SupplyChainTradeTransaction.ApplicableHeaderTradeSettlement.SpecifiedTradeSettlementHeaderMonetarySummation.TaxBasisTotalAmount}}`
     - `Montant_TTC` : `{{3.CrossIndustryInvoice.SupplyChainTradeTransaction.ApplicableHeaderTradeSettlement.SpecifiedTradeSettlementHeaderMonetarySummation.GrandTotalAmount}}`
4. **Variables Normalisées — `Tools > Set Multiple Variables`**
   - `Date_ISO` : `{{formatDate(parseDate(Date_Brute; "YYYYMMDD"); "YYYY-MM-DD")}}`
   - `Fournisseur_Slug` : `{{substring(replace(upper(ascii(Fournisseur)); "/[^A-Z0-9]+/g"; "-"); 0; 32)}}`
   - `Montant_Fixe` : `{{formatNumber(Montant_TTC; 2; "."; "")}}`
   - `Nom_Fichier_Normalise` : `{{Date_ISO}}_{{Fournisseur_Slug}}_{{Montant_Fixe}}.pdf`
   - `Empreinte_Doublon` : `{{SIREN}}_{{upper(Num_Facture)}}_{{Montant_Fixe}}`
5. **Contrôle Anti-Doublon — `Google Sheets > Search Rows` (ou `Airtable > Search Records`)**
   - Feuille : `Achats_Fournisseurs`
   - Filtre : Colonne `Empreinte_Doublon` `Equal to` `{{4.Empreinte_Doublon}}`
   - **Filtre Make après le module 5 (`Total number of bundles = 0`)** : `{{5.__IMTLENGTH__}} = 0` (bloque net tout doublon).
6. **Classement Drive — `Google Drive > Upload a File`**
   - Destination Folder : `Factures Fournisseurs 2026-2027`
   - File Name : `{{4.Nom_Fichier_Normalise}}` (`AAAA-MM-JJ_FOURNISSEUR_MONTANT.pdf`)
   - Data : `{{2.data}}`
7. **Écriture Comptable — `Google Sheets > Add a Row` (ou `Airtable > Create a Record`)**
   - Mappez les colonnes `Date_Facture`, `Fournisseur`, `SIREN`, `Num_Facture`, `Format_Source`, `Montant_HT`, `Montant_TVA`, `Montant_TTC`, `Nom_Fichier`, `Lien_Drive` (`{{6.webViewLink}}`), `Empreinte_Doublon`.

---

## Fiche Make #2 — Relances Impayés Graduées B2B (Art. L441-10 Code de Commerce)

### Architecture Make (Planification Lun–Ven à 08h30 + Routeur 3 branches)
1. ** Planification — `Schedule Setting`** : `Days of the week` (Lundi à Vendredi) à `08:30` (`Europe/Paris`).
2. **Lecture — `Google Sheets > Search Rows`** sur l'onglet `Factures_Clients` :
   - Filtre : `Statut_Paiement != PAYEE` ET `Bloquer_Relance != OUI`.
3. **Calcul Juridique — `Tools > Set Multiple Variables`** :
   - `Jours_Retard` : `{{floor((now - parseDate(2.Date_Echeance; "YYYY-MM-DD")) / 86400000)}}`
   - `Penalites_L441_10` : `{{if(2.Type_Client = "B2B"; round(2.Montant_TTC * 0.1315 * (Jours_Retard / 365) * 100) / 100; 0)}}`
   - `Indemnite_Forfaitaire` : `{{if(2.Type_Client = "B2B"; 40; 0)}}`
   - `Total_Exigible` : `{{2.Montant_TTC + Penalites_L441_10 + Indemnite_Forfaitaire}}`
4. **Routeur Gradué — `Flow Control > Router` (3 branches exclusives)** :
   - **Branche 1 (J+3 Courtois)** : Filtre `Jours_Retard >= 3` ET `Jours_Retard < 10` ET `2.Dernier_Niveau_Relance < 1` -> `Gmail > Create a Draft` -> `Google Sheets > Update a Row` (`Dernier_Niveau_Relance = 1`).
   - **Branche 2 (J+10 Rappel Ferme)** : Filtre `Jours_Retard >= 10` ET `Jours_Retard < 21` ET `2.Dernier_Niveau_Relance < 2` -> `Gmail > Create a Draft` -> `Google Sheets > Update a Row` (`Dernier_Niveau_Relance = 2`).
   - **Branche 3 (J+21 Pré-Mise en Demeure L441-10)** : Filtre `Jours_Retard >= 21` ET `2.Dernier_Niveau_Relance < 3` -> `Gmail > Create a Draft` (incluant `Penalites_L441_10` + indemnité forfaitaire de `40,00 EUR` art. L441-10 & D441-5 C. com.) -> `Google Sheets > Update a Row` (`Dernier_Niveau_Relance = 3`).
5. **Synthèse Dirigeant — `Tools > Text Aggregator` + `Gmail > Send an Email`** :
   - Agrège les brouillons créés ce matin et envoie un email unique de validation à la direction.

---

## Fiche Make #3 — Météo Hebdomadaire Trésorerie, Marge & Seuils Fiscaux/TVA 2027

### Architecture Make (Tous les lundis à 08h00)
1. **Planification — `Schedule Setting`** : Chaque `Lundi` à `08:00` (`Europe/Paris`).
2. **Agrégation Ventes du Mois & Année — `Google Sheets > Search Rows` + `Numeric Aggregator`** :
   - Agrégateur 1 (`SUM` sur `Montant_HT` où `Statut_Paiement = PAYEE` et `Date_Paiement` commence par `{{formatDate(now; "YYYY-MM")}}`) -> `CA_Encaisse_Mois_HT`.
   - Agrégateur 2 (`SUM` sur `Montant_HT` où `Statut_Paiement = PAYEE` et `Date_Paiement` commence par `{{formatDate(now; "YYYY")}}`) -> `CA_Annuel_YTD`.
   - Agrégateur 3 (`SUM` sur `Montant_TTC` où `Statut_Paiement = EN_ATTENTE`) -> `Encours_Client_TTC`.
3. **Agrégation Achats du Mois — `Google Sheets > Search Rows` (`Achats_Fournisseurs`) + `Numeric Aggregator`** :
   - `SUM` sur `Montant_HT` du mois en cours -> `Depenses_Mois_HT`.
4. **Calcul Marge & Seuils 2027 — `Tools > Set Multiple Variables`** :
   - `Charges_Sociales_Est` : `{{round(CA_Encaisse_Mois_HT * 0.246 * 100) / 100}}`
   - `Marge_Nette_Mois` : `{{CA_Encaisse_Mois_HT - Depenses_Mois_HT - Charges_Sociales_Est}}`
   - `Distance_Seuil_TVA_Base` : `{{37500 - CA_Annuel_YTD}}` (ou `85000` en négoce/vente)
   - `Distance_Seuil_TVA_Majore` : `{{41250 - CA_Annuel_YTD}}` (ou `93500` en négoce/vente)
5. **Diffusion & Archivage — `Gmail > Send an Email` + `Google Sheets > Add a Row` (`Historique_KPI_Hebdo`)** :
   - Envoie le tableau HTML récapitulatif au dirigeant et archive la ligne hebdomadaire.
